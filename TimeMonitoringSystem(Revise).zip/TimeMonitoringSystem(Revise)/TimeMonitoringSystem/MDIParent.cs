﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeMonitoringSystem
{
    public partial class MDIParent : Form
    {

        public MDIParent(string name)
        {
            InitializeComponent();
            lblstatus.Text = "Name: " + name;
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FormLogIn().Show();
            this.Hide();
        }

        private void addFacultyUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageUserForm manageUser = new ManageUserForm();
            manageUser.MdiParent = this;
            manageUser.Show();
        }
    }
}
