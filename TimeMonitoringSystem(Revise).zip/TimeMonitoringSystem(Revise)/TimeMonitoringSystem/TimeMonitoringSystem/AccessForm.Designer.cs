﻿namespace TimeMonitoringSystem
{
    partial class AccessForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblname = new System.Windows.Forms.Label();
            this.DropdownMenuDashboard = new RJCodeAdvance.RJControls.RJDropdownMenu(this.components);
            this.attendanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DropdownMenuStudData = new RJCodeAdvance.RJControls.RJDropdownMenu(this.components);
            this.viewStudentDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudentDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DropdownMenuUserData = new RJCodeAdvance.RJControls.RJDropdownMenu(this.components);
            this.viewUserDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addUserDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iconButton8 = new FontAwesome.Sharp.IconButton();
            this.btnlogout = new FontAwesome.Sharp.IconButton();
            this.btnuserdata = new FontAwesome.Sharp.IconButton();
            this.btnstuddata = new FontAwesome.Sharp.IconButton();
            this.btndashboard = new FontAwesome.Sharp.IconButton();
            this.iconButton6 = new FontAwesome.Sharp.IconButton();
            this.iconButton5 = new FontAwesome.Sharp.IconButton();
            this.iconButton4 = new FontAwesome.Sharp.IconButton();
            this.rjCircularPictureBox1 = new RJCodeAdvance.RJControls.RJCircularPictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.DropdownMenuDashboard.SuspendLayout();
            this.DropdownMenuStudData.SuspendLayout();
            this.DropdownMenuUserData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rjCircularPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumPurple;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.iconButton8);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(175, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(829, 61);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnlogout);
            this.panel2.Controls.Add(this.btnuserdata);
            this.panel2.Controls.Add(this.btnstuddata);
            this.panel2.Controls.Add(this.btndashboard);
            this.panel2.Controls.Add(this.iconButton6);
            this.panel2.Controls.Add(this.iconButton5);
            this.panel2.Controls.Add(this.iconButton4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(175, 569);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel3.Controls.Add(this.lblname);
            this.panel3.Controls.Add(this.rjCircularPictureBox1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(173, 171);
            this.panel3.TabIndex = 1;
            // 
            // lblname
            // 
            this.lblname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.ForeColor = System.Drawing.Color.White;
            this.lblname.Location = new System.Drawing.Point(46, 136);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(81, 20);
            this.lblname.TabIndex = 1;
            this.lblname.Text = "************";
            this.lblname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DropdownMenuDashboard
            // 
            this.DropdownMenuDashboard.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.DropdownMenuDashboard.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DropdownMenuDashboard.IsMainMenu = false;
            this.DropdownMenuDashboard.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.attendanceToolStripMenuItem,
            this.scheduleToolStripMenuItem});
            this.DropdownMenuDashboard.MenuItemHeight = 30;
            this.DropdownMenuDashboard.MenuItemTextColor = System.Drawing.Color.Black;
            this.DropdownMenuDashboard.Name = "DropdownMenuDashboard";
            this.DropdownMenuDashboard.PrimaryColor = System.Drawing.Color.Empty;
            this.DropdownMenuDashboard.Size = new System.Drawing.Size(155, 52);
            // 
            // attendanceToolStripMenuItem
            // 
            this.attendanceToolStripMenuItem.Name = "attendanceToolStripMenuItem";
            this.attendanceToolStripMenuItem.Size = new System.Drawing.Size(154, 24);
            this.attendanceToolStripMenuItem.Text = "Attendance";
            // 
            // scheduleToolStripMenuItem
            // 
            this.scheduleToolStripMenuItem.Name = "scheduleToolStripMenuItem";
            this.scheduleToolStripMenuItem.Size = new System.Drawing.Size(154, 24);
            this.scheduleToolStripMenuItem.Text = "Schedule";
            // 
            // DropdownMenuStudData
            // 
            this.DropdownMenuStudData.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.DropdownMenuStudData.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DropdownMenuStudData.IsMainMenu = false;
            this.DropdownMenuStudData.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewStudentDataToolStripMenuItem,
            this.addStudentDataToolStripMenuItem});
            this.DropdownMenuStudData.MenuItemHeight = 25;
            this.DropdownMenuStudData.MenuItemTextColor = System.Drawing.Color.Black;
            this.DropdownMenuStudData.Name = "DropdownMenuStudData";
            this.DropdownMenuStudData.PrimaryColor = System.Drawing.Color.Empty;
            this.DropdownMenuStudData.Size = new System.Drawing.Size(202, 52);
            // 
            // viewStudentDataToolStripMenuItem
            // 
            this.viewStudentDataToolStripMenuItem.Name = "viewStudentDataToolStripMenuItem";
            this.viewStudentDataToolStripMenuItem.Size = new System.Drawing.Size(201, 24);
            this.viewStudentDataToolStripMenuItem.Text = "View Student Data";
            // 
            // addStudentDataToolStripMenuItem
            // 
            this.addStudentDataToolStripMenuItem.Name = "addStudentDataToolStripMenuItem";
            this.addStudentDataToolStripMenuItem.Size = new System.Drawing.Size(201, 24);
            this.addStudentDataToolStripMenuItem.Text = "Add Student Data";
            // 
            // DropdownMenuUserData
            // 
            this.DropdownMenuUserData.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.DropdownMenuUserData.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DropdownMenuUserData.IsMainMenu = false;
            this.DropdownMenuUserData.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewUserDataToolStripMenuItem,
            this.addUserDataToolStripMenuItem});
            this.DropdownMenuUserData.MenuItemHeight = 25;
            this.DropdownMenuUserData.MenuItemTextColor = System.Drawing.Color.Black;
            this.DropdownMenuUserData.Name = "DropdownMenuUserData";
            this.DropdownMenuUserData.PrimaryColor = System.Drawing.Color.Empty;
            this.DropdownMenuUserData.Size = new System.Drawing.Size(180, 52);
            // 
            // viewUserDataToolStripMenuItem
            // 
            this.viewUserDataToolStripMenuItem.Name = "viewUserDataToolStripMenuItem";
            this.viewUserDataToolStripMenuItem.Size = new System.Drawing.Size(179, 24);
            this.viewUserDataToolStripMenuItem.Text = "View User Data";
            // 
            // addUserDataToolStripMenuItem
            // 
            this.addUserDataToolStripMenuItem.Name = "addUserDataToolStripMenuItem";
            this.addUserDataToolStripMenuItem.Size = new System.Drawing.Size(179, 24);
            this.addUserDataToolStripMenuItem.Text = "Add User Data";
            // 
            // iconButton8
            // 
            this.iconButton8.FlatAppearance.BorderSize = 0;
            this.iconButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton8.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton8.IconChar = FontAwesome.Sharp.IconChar.Bell;
            this.iconButton8.IconColor = System.Drawing.Color.Black;
            this.iconButton8.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.iconButton8.IconSize = 40;
            this.iconButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton8.Location = new System.Drawing.Point(6, 12);
            this.iconButton8.Name = "iconButton8";
            this.iconButton8.Size = new System.Drawing.Size(150, 40);
            this.iconButton8.TabIndex = 9;
            this.iconButton8.Text = "Notification";
            this.iconButton8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton8.UseVisualStyleBackColor = true;
            // 
            // btnlogout
            // 
            this.btnlogout.FlatAppearance.BorderSize = 0;
            this.btnlogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlogout.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.IconChar = FontAwesome.Sharp.IconChar.SignOutAlt;
            this.btnlogout.IconColor = System.Drawing.Color.Black;
            this.btnlogout.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnlogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlogout.Location = new System.Drawing.Point(11, 524);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Size = new System.Drawing.Size(150, 40);
            this.btnlogout.TabIndex = 8;
            this.btnlogout.Text = "Log Out";
            this.btnlogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnlogout.UseVisualStyleBackColor = true;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // btnuserdata
            // 
            this.btnuserdata.FlatAppearance.BorderSize = 0;
            this.btnuserdata.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnuserdata.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnuserdata.IconChar = FontAwesome.Sharp.IconChar.UserFriends;
            this.btnuserdata.IconColor = System.Drawing.Color.Black;
            this.btnuserdata.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnuserdata.IconSize = 40;
            this.btnuserdata.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnuserdata.Location = new System.Drawing.Point(12, 269);
            this.btnuserdata.Name = "btnuserdata";
            this.btnuserdata.Size = new System.Drawing.Size(150, 40);
            this.btnuserdata.TabIndex = 4;
            this.btnuserdata.Text = "Users Data";
            this.btnuserdata.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnuserdata.UseVisualStyleBackColor = true;
            this.btnuserdata.Click += new System.EventHandler(this.btnuserdata_Click);
            // 
            // btnstuddata
            // 
            this.btnstuddata.FlatAppearance.BorderSize = 0;
            this.btnstuddata.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnstuddata.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstuddata.IconChar = FontAwesome.Sharp.IconChar.IdCard;
            this.btnstuddata.IconColor = System.Drawing.Color.Black;
            this.btnstuddata.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnstuddata.IconSize = 40;
            this.btnstuddata.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnstuddata.Location = new System.Drawing.Point(11, 223);
            this.btnstuddata.Name = "btnstuddata";
            this.btnstuddata.Size = new System.Drawing.Size(150, 40);
            this.btnstuddata.TabIndex = 3;
            this.btnstuddata.Text = "Students Data";
            this.btnstuddata.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnstuddata.UseVisualStyleBackColor = true;
            this.btnstuddata.Click += new System.EventHandler(this.btnstuddata_Click);
            // 
            // btndashboard
            // 
            this.btndashboard.FlatAppearance.BorderSize = 0;
            this.btndashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndashboard.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndashboard.IconChar = FontAwesome.Sharp.IconChar.ChartBar;
            this.btndashboard.IconColor = System.Drawing.Color.Black;
            this.btndashboard.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btndashboard.IconSize = 40;
            this.btndashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndashboard.Location = new System.Drawing.Point(11, 177);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(150, 40);
            this.btndashboard.TabIndex = 2;
            this.btndashboard.Text = "Dashboard";
            this.btndashboard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btndashboard.UseVisualStyleBackColor = true;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // iconButton6
            // 
            this.iconButton6.FlatAppearance.BorderSize = 0;
            this.iconButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton6.IconChar = FontAwesome.Sharp.IconChar.UserShield;
            this.iconButton6.IconColor = System.Drawing.Color.Black;
            this.iconButton6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton6.IconSize = 40;
            this.iconButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton6.Location = new System.Drawing.Point(11, 407);
            this.iconButton6.Name = "iconButton6";
            this.iconButton6.Size = new System.Drawing.Size(150, 40);
            this.iconButton6.TabIndex = 7;
            this.iconButton6.Text = "Admission";
            this.iconButton6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton6.UseVisualStyleBackColor = true;
            // 
            // iconButton5
            // 
            this.iconButton5.FlatAppearance.BorderSize = 0;
            this.iconButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton5.IconChar = FontAwesome.Sharp.IconChar.Info;
            this.iconButton5.IconColor = System.Drawing.Color.Black;
            this.iconButton5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton5.IconSize = 40;
            this.iconButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton5.Location = new System.Drawing.Point(11, 361);
            this.iconButton5.Name = "iconButton5";
            this.iconButton5.Size = new System.Drawing.Size(150, 40);
            this.iconButton5.TabIndex = 6;
            this.iconButton5.Text = "Guidance";
            this.iconButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton5.UseVisualStyleBackColor = true;
            // 
            // iconButton4
            // 
            this.iconButton4.FlatAppearance.BorderSize = 0;
            this.iconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton4.IconChar = FontAwesome.Sharp.IconChar.Database;
            this.iconButton4.IconColor = System.Drawing.Color.Black;
            this.iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton4.IconSize = 40;
            this.iconButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton4.Location = new System.Drawing.Point(11, 315);
            this.iconButton4.Name = "iconButton4";
            this.iconButton4.Size = new System.Drawing.Size(150, 40);
            this.iconButton4.TabIndex = 5;
            this.iconButton4.Text = "Faculty";
            this.iconButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton4.UseVisualStyleBackColor = true;
            // 
            // rjCircularPictureBox1
            // 
            this.rjCircularPictureBox1.BorderCapStyle = System.Drawing.Drawing2D.DashCap.Flat;
            this.rjCircularPictureBox1.BorderColor = System.Drawing.Color.RoyalBlue;
            this.rjCircularPictureBox1.BorderColor2 = System.Drawing.Color.HotPink;
            this.rjCircularPictureBox1.BorderLineStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.rjCircularPictureBox1.BorderSize = 2;
            this.rjCircularPictureBox1.GradientAngle = 50F;
            this.rjCircularPictureBox1.Location = new System.Drawing.Point(27, 12);
            this.rjCircularPictureBox1.Name = "rjCircularPictureBox1";
            this.rjCircularPictureBox1.Size = new System.Drawing.Size(121, 121);
            this.rjCircularPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rjCircularPictureBox1.TabIndex = 0;
            this.rjCircularPictureBox1.TabStop = false;
            // 
            // AccessForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 569);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AccessForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AccessForm";
            this.Load += new System.EventHandler(this.AccessForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.DropdownMenuDashboard.ResumeLayout(false);
            this.DropdownMenuStudData.ResumeLayout(false);
            this.DropdownMenuUserData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rjCircularPictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private RJCodeAdvance.RJControls.RJCircularPictureBox rjCircularPictureBox1;
        private FontAwesome.Sharp.IconButton iconButton4;
        private FontAwesome.Sharp.IconButton btnuserdata;
        private FontAwesome.Sharp.IconButton btnstuddata;
        private FontAwesome.Sharp.IconButton btndashboard;
        private FontAwesome.Sharp.IconButton iconButton6;
        private FontAwesome.Sharp.IconButton iconButton5;
        private System.Windows.Forms.Label lblname;
        private FontAwesome.Sharp.IconButton btnlogout;
        private FontAwesome.Sharp.IconButton iconButton8;
        private RJCodeAdvance.RJControls.RJDropdownMenu DropdownMenuDashboard;
        private System.Windows.Forms.ToolStripMenuItem attendanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scheduleToolStripMenuItem;
        private RJCodeAdvance.RJControls.RJDropdownMenu DropdownMenuStudData;
        private System.Windows.Forms.ToolStripMenuItem viewStudentDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addStudentDataToolStripMenuItem;
        private RJCodeAdvance.RJControls.RJDropdownMenu DropdownMenuUserData;
        private System.Windows.Forms.ToolStripMenuItem viewUserDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addUserDataToolStripMenuItem;
    }
}