﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeMonitoringSystem
{
    public partial class AccessForm : Form
    {
        public AccessForm(string name)
        {
            InitializeComponent();
            lblname.Text = name;
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            new FormLogIn().Show();
            this.Hide();
        }

        private void btnuserdata_Click(object sender, EventArgs e)
        {
            DropdownMenuUserData.Show(btnuserdata, btnuserdata.Width, 0);
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            DropdownMenuDashboard.Show(btndashboard, btndashboard.Width, 0);
        }

        private void btnstuddata_Click(object sender, EventArgs e)
        {
            DropdownMenuStudData.Show(btnstuddata, btnstuddata.Width, 0);
        }

        private void AccessForm_Load(object sender, EventArgs e)
        {
            if (lblname.Text == "Admission")
            {
                btnuserdata.Enabled = false;
            }
        }
    }
}
