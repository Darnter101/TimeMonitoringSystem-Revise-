﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TimeMonitoringSystem
{
    public partial class FormLogIn : Form
    {
        string connectionString = "server=localhost;port=3306;database=usersaccess;uid=root;pwd=;SslMode = none;";

        public FormLogIn()
        {
            InitializeComponent();
        }

        private void Btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conn = new MySqlConnection(connectionString);
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("select name, user_type from usersdata where username='" + txtuser.Texts + "' and password='" + txtpass.Texts + "'", conn);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                DataTable data = new DataTable();
                adapter.Fill(data);

                if (data.Rows.Count == 1)
                {
                    if (data.Rows[0][1].ToString() == "Administrator")
                    {
                        new AccessForm(data.Rows[0][0].ToString()).Show();
                    }
                    else if (data.Rows[0][1].ToString() == "Assistant Pricipal")
                    {
                        new AccessForm(data.Rows[0][0].ToString()).Show();
                    }
                    else if (data.Rows[0][1].ToString() == "Admission")
                    {
                        new AccessForm(data.Rows[0][0].ToString()).Show();
                    }
                    else if (data.Rows[0][1].ToString() == "Guidance")
                    {
                        new AccessForm(data.Rows[0][0].ToString()).Show();
                    }
                    else if (data.Rows[0][1].ToString() == "Faculty User")
                    {
                        //new UserForm(data.Rows[0][0].ToString()).Show();
                    }
                    this.Hide();
                }
                else if (txtuser.Texts == " " || txtpass.Texts == "")
                {
                    lblmerror.Text = "Empty Failed!";
                    lblmerror.Show();
                    iconerror.Show();
                }
                else
                {
                    lblmerror.Text = "Login Denied!";
                    lblmerror.Show();
                    iconerror.Show();
                }
                conn.Close();
                txtuser.Texts = " ";
                txtpass.Texts = " ";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
