﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeMonitoringSystem
{
    public partial class AccessForm : Form
    {
        public AccessForm(string name)
        {
            InitializeComponent();
            lblname.Text = name;
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            new FormLogIn().Show();
            this.Hide();
        }

        private void btnuserdata_Click(object sender, EventArgs e)
        {
            if (panel4.Height == 147)
            {
                panel4.Height = 47;
            }
            else
            {
                panel4.Height = 147;
            }
            panel5.Height = 47;
            panel6.Height = 47;
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
            if (panel5.Height == 147)
            {
                panel5.Height = 47;
            }
            else
            {
                panel5.Height = 147;
            }
            panel4.Height = 47;
            panel6.Height = 47;
        }

        private void btnstuddata_Click(object sender, EventArgs e)
        {
            if (panel6.Height == 147)
            {
                panel6.Height = 47;
            }
            else
            {
                panel6.Height = 147;
            }
            panel4.Height = 47;
            panel5.Height = 47;
        }
    }
}
