﻿namespace TimeMonitoringSystem
{
    partial class MDIParent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.dashboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attendaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentsDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewStudentsDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudentsDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usersDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewUsersDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addFacultyUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.facultyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.facultyRoosterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classScheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guidanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.admissionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewStudentsDataToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.viewStudentsDataToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.notificationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblstatus = new System.Windows.Forms.Label();
            this.rjCircularPictureBox1 = new RJCodeAdvance.RJControls.RJCircularPictureBox();
            this.menuStrip.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rjCircularPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dashboardToolStripMenuItem,
            this.logOutToolStripMenuItem,
            this.studentsDataToolStripMenuItem,
            this.usersDataToolStripMenuItem,
            this.facultyToolStripMenuItem,
            this.guidanceToolStripMenuItem,
            this.admissionToolStripMenuItem,
            this.notificationToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 110);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.menuStrip.Size = new System.Drawing.Size(149, 343);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // dashboardToolStripMenuItem
            // 
            this.dashboardToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.attendaceToolStripMenuItem,
            this.scheduleToolStripMenuItem});
            this.dashboardToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboardToolStripMenuItem.Image = global::TimeMonitoringSystem.Properties.Resources.User_Interface_Content_icon__1_;
            this.dashboardToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dashboardToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.dashboardToolStripMenuItem.Name = "dashboardToolStripMenuItem";
            this.dashboardToolStripMenuItem.Size = new System.Drawing.Size(142, 36);
            this.dashboardToolStripMenuItem.Text = "Dashboard";
            // 
            // attendaceToolStripMenuItem
            // 
            this.attendaceToolStripMenuItem.Name = "attendaceToolStripMenuItem";
            this.attendaceToolStripMenuItem.Size = new System.Drawing.Size(146, 24);
            this.attendaceToolStripMenuItem.Text = "Attendace";
            // 
            // scheduleToolStripMenuItem
            // 
            this.scheduleToolStripMenuItem.Name = "scheduleToolStripMenuItem";
            this.scheduleToolStripMenuItem.Size = new System.Drawing.Size(146, 24);
            this.scheduleToolStripMenuItem.Text = "Schedule";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.logOutToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(142, 24);
            this.logOutToolStripMenuItem.Text = "Log Out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // studentsDataToolStripMenuItem
            // 
            this.studentsDataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewStudentsDataToolStripMenuItem,
            this.addStudentsDataToolStripMenuItem});
            this.studentsDataToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentsDataToolStripMenuItem.Image = global::TimeMonitoringSystem.Properties.Resources.user_icon;
            this.studentsDataToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.studentsDataToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.studentsDataToolStripMenuItem.Name = "studentsDataToolStripMenuItem";
            this.studentsDataToolStripMenuItem.Size = new System.Drawing.Size(142, 36);
            this.studentsDataToolStripMenuItem.Text = "Students Data";
            // 
            // viewStudentsDataToolStripMenuItem
            // 
            this.viewStudentsDataToolStripMenuItem.Name = "viewStudentsDataToolStripMenuItem";
            this.viewStudentsDataToolStripMenuItem.Size = new System.Drawing.Size(207, 24);
            this.viewStudentsDataToolStripMenuItem.Text = "View Students Data";
            // 
            // addStudentsDataToolStripMenuItem
            // 
            this.addStudentsDataToolStripMenuItem.Name = "addStudentsDataToolStripMenuItem";
            this.addStudentsDataToolStripMenuItem.Size = new System.Drawing.Size(207, 24);
            this.addStudentsDataToolStripMenuItem.Text = "Add Students Data";
            // 
            // usersDataToolStripMenuItem
            // 
            this.usersDataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewUsersDataToolStripMenuItem,
            this.addFacultyUsersToolStripMenuItem});
            this.usersDataToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usersDataToolStripMenuItem.Image = global::TimeMonitoringSystem.Properties.Resources.Users_icon;
            this.usersDataToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.usersDataToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.usersDataToolStripMenuItem.Name = "usersDataToolStripMenuItem";
            this.usersDataToolStripMenuItem.Size = new System.Drawing.Size(142, 36);
            this.usersDataToolStripMenuItem.Text = "Manage Users";
            // 
            // viewUsersDataToolStripMenuItem
            // 
            this.viewUsersDataToolStripMenuItem.Name = "viewUsersDataToolStripMenuItem";
            this.viewUsersDataToolStripMenuItem.Size = new System.Drawing.Size(194, 24);
            this.viewUsersDataToolStripMenuItem.Text = "View Users Data";
            // 
            // addFacultyUsersToolStripMenuItem
            // 
            this.addFacultyUsersToolStripMenuItem.Name = "addFacultyUsersToolStripMenuItem";
            this.addFacultyUsersToolStripMenuItem.Size = new System.Drawing.Size(194, 24);
            this.addFacultyUsersToolStripMenuItem.Text = "Add Faculty Users";
            this.addFacultyUsersToolStripMenuItem.Click += new System.EventHandler(this.addFacultyUsersToolStripMenuItem_Click);
            // 
            // facultyToolStripMenuItem
            // 
            this.facultyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.facultyRoosterToolStripMenuItem,
            this.classScheduleToolStripMenuItem});
            this.facultyToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.facultyToolStripMenuItem.Image = global::TimeMonitoringSystem.Properties.Resources.Users_Guest_icon;
            this.facultyToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.facultyToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.facultyToolStripMenuItem.Name = "facultyToolStripMenuItem";
            this.facultyToolStripMenuItem.Size = new System.Drawing.Size(142, 36);
            this.facultyToolStripMenuItem.Text = "Faculty";
            // 
            // facultyRoosterToolStripMenuItem
            // 
            this.facultyRoosterToolStripMenuItem.Name = "facultyRoosterToolStripMenuItem";
            this.facultyRoosterToolStripMenuItem.Size = new System.Drawing.Size(178, 24);
            this.facultyRoosterToolStripMenuItem.Text = "Faculty Rooster";
            // 
            // classScheduleToolStripMenuItem
            // 
            this.classScheduleToolStripMenuItem.Name = "classScheduleToolStripMenuItem";
            this.classScheduleToolStripMenuItem.Size = new System.Drawing.Size(178, 24);
            this.classScheduleToolStripMenuItem.Text = "Class Schedule";
            // 
            // guidanceToolStripMenuItem
            // 
            this.guidanceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reportsToolStripMenuItem});
            this.guidanceToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guidanceToolStripMenuItem.Image = global::TimeMonitoringSystem.Properties.Resources.Business_Questions_icon;
            this.guidanceToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.guidanceToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.guidanceToolStripMenuItem.Name = "guidanceToolStripMenuItem";
            this.guidanceToolStripMenuItem.Size = new System.Drawing.Size(142, 36);
            this.guidanceToolStripMenuItem.Text = "Guidance";
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(129, 24);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // admissionToolStripMenuItem
            // 
            this.admissionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewStudentsDataToolStripMenuItem1,
            this.viewStudentsDataToolStripMenuItem2});
            this.admissionToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admissionToolStripMenuItem.Image = global::TimeMonitoringSystem.Properties.Resources.Apps_user_info_icon;
            this.admissionToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.admissionToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.admissionToolStripMenuItem.Name = "admissionToolStripMenuItem";
            this.admissionToolStripMenuItem.Size = new System.Drawing.Size(142, 36);
            this.admissionToolStripMenuItem.Text = "Admission";
            // 
            // viewStudentsDataToolStripMenuItem1
            // 
            this.viewStudentsDataToolStripMenuItem1.Name = "viewStudentsDataToolStripMenuItem1";
            this.viewStudentsDataToolStripMenuItem1.Size = new System.Drawing.Size(207, 24);
            this.viewStudentsDataToolStripMenuItem1.Text = "View Students Data";
            // 
            // viewStudentsDataToolStripMenuItem2
            // 
            this.viewStudentsDataToolStripMenuItem2.Name = "viewStudentsDataToolStripMenuItem2";
            this.viewStudentsDataToolStripMenuItem2.Size = new System.Drawing.Size(207, 24);
            this.viewStudentsDataToolStripMenuItem2.Text = "Add Students Data";
            // 
            // notificationToolStripMenuItem
            // 
            this.notificationToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.notificationToolStripMenuItem.Image = global::TimeMonitoringSystem.Properties.Resources.confirm_notification_icon;
            this.notificationToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.notificationToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.notificationToolStripMenuItem.Name = "notificationToolStripMenuItem";
            this.notificationToolStripMenuItem.Size = new System.Drawing.Size(142, 36);
            this.notificationToolStripMenuItem.Text = "Notification";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblstatus);
            this.panel1.Controls.Add(this.rjCircularPictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(749, 110);
            this.panel1.TabIndex = 4;
            // 
            // lblstatus
            // 
            this.lblstatus.AutoSize = true;
            this.lblstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstatus.Location = new System.Drawing.Point(140, 18);
            this.lblstatus.Name = "lblstatus";
            this.lblstatus.Size = new System.Drawing.Size(45, 16);
            this.lblstatus.TabIndex = 1;
            this.lblstatus.Text = "Status";
            // 
            // rjCircularPictureBox1
            // 
            this.rjCircularPictureBox1.BorderCapStyle = System.Drawing.Drawing2D.DashCap.Flat;
            this.rjCircularPictureBox1.BorderColor = System.Drawing.Color.Black;
            this.rjCircularPictureBox1.BorderColor2 = System.Drawing.Color.HotPink;
            this.rjCircularPictureBox1.BorderLineStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.rjCircularPictureBox1.BorderSize = 2;
            this.rjCircularPictureBox1.GradientAngle = 50F;
            this.rjCircularPictureBox1.Location = new System.Drawing.Point(12, 12);
            this.rjCircularPictureBox1.Name = "rjCircularPictureBox1";
            this.rjCircularPictureBox1.Size = new System.Drawing.Size(83, 83);
            this.rjCircularPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rjCircularPictureBox1.TabIndex = 0;
            this.rjCircularPictureBox1.TabStop = false;
            // 
            // MDIParent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 453);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.panel1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MDIParent";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MDIParent";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rjCircularPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem dashboardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentsDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewStudentsDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addStudentsDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usersDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem facultyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guidanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem admissionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notificationToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private RJCodeAdvance.RJControls.RJCircularPictureBox rjCircularPictureBox1;
        private System.Windows.Forms.ToolStripMenuItem attendaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewUsersDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addFacultyUsersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scheduleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem facultyRoosterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewStudentsDataToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem viewStudentsDataToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem classScheduleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.Label lblstatus;
    }
}



