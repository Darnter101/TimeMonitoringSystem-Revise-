﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TimeMonitoringSystem
{
    public partial class UserDataInfo : UserControl
    {
        public UserDataInfo()
        {
            InitializeComponent();
        }
        //This is my connection string i have assigned the database file address path
        string connectionString = "server=localhost;port=3306;database=usersaccess;uid=root;pwd=;SslMode = none;";

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                //This is my insert query in which i am taking input from the user through windows forms
                string query = "insert into usersdata(user_id, name, age, gender, mobile, address, user_type, username, password) values('" + this.txtuserID.Text + "','" + this.txtuserName.Text + "','" + this.txtuserAge.Text + "','" + this.cmbuserGen.Text + "','" + this.txtuserCP.Text + "','" + this.txtuserLoc.Text + "','" + this.cmbuserType.Text + "','" + this.txtuserkey.Text + "','" + this.txtpasskey.Text + "');";
                //This is  MySqlConnection here i have created the object and pass my connection string.
                MySqlConnection connection = new MySqlConnection(connectionString);
                //This is command class which will handle the query and connection object.
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader reader;
                connection.Open();
                // Here our query will be executed and data saved into the database.
                reader = cmd.ExecuteReader();
                MessageBox.Show("Save Success!");
                while (reader.Read())
                {

                }
                //Connection closed here
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                //This is my delete query in which i am taking input from the user through windows forms
                string query = "delete from usersdata where user_id= '"+ this.txtuserID.Text +"';";
                MySqlConnection connection = new MySqlConnection(connectionString);
                //This is command class which will handle the query and connection object.
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader reader;
                connection.Open();
                // Here our query will be executed and data saved into the database.
                reader = cmd.ExecuteReader();
                MessageBox.Show("Delete success!");
                while (reader.Read())
                {

                }
                //Connection closed here
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                //This is my update query in which i am taking input from the user through windows forms and update the record.
                string query = "update usersdata set user_id='"+ this.txtuserID.Text +"', name='"+ this.txtuserName.Text +"', age='"+ this.txtuserAge.Text +"', gender='"+ this.cmbuserGen.Text +"', mobile='"+ this.txtuserCP.Text +"', address='"+ this.txtuserLoc.Text +"', user_type='"+ this.cmbuserType.Text +"', username='"+ this.txtuserkey.Text +"', password='"+ this.txtpasskey.Text +"';";
                MySqlConnection connection = new MySqlConnection(connectionString);
                //This is command class which will handle the query and connection object.
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader reader;
                connection.Open();
                // Here our query will be executed and data saved into the database.
                reader = cmd.ExecuteReader();
                MessageBox.Show("Update success!");
                while (reader.Read())
                {

                }
                //Connection closed here
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnerase_Click(object sender, EventArgs e)
        {
            txtpasskey.Clear();
            txtuserAge.Clear();
            txtuserCP.Clear();
            txtuserID.Clear();
            txtuserkey.Clear();
            txtuserLoc.Clear();
            txtuserName.Clear();
            cmbuserGen.Text = " ";
            cmbuserType.Text = " ";
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection connection = new MySqlConnection(connectionString);
                MySqlCommand cmd = new MySqlCommand("select *from usersdata where user_id='"+ this.txtuserID.Text +"'", connection);
                MySqlDataAdapter data = new MySqlDataAdapter();
                data.SelectCommand = cmd;

                DataSet ds = new DataSet("info");
                data.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void showUserData()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("select * from usersdata", connection);
                DataTable data = new DataTable();
                adapter.Fill(data);
                dataGridView1.DataSource = data;
            }
        }

        private void UserDataInfo_Load(object sender, EventArgs e)
        {
            showUserData();
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            showUserData();
        }
    }
}
