﻿namespace TimeMonitoringSystem
{
    partial class AccessForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.NavBar = new System.Windows.Forms.Panel();
            this.iconButton8 = new FontAwesome.Sharp.IconButton();
            this.ModuleBar = new System.Windows.Forms.Panel();
            this.btnlogout = new FontAwesome.Sharp.IconButton();
            this.btnuserdata = new FontAwesome.Sharp.IconButton();
            this.btnstuddata = new FontAwesome.Sharp.IconButton();
            this.btndashboard = new FontAwesome.Sharp.IconButton();
            this.iconButton6 = new FontAwesome.Sharp.IconButton();
            this.iconButton5 = new FontAwesome.Sharp.IconButton();
            this.iconButton4 = new FontAwesome.Sharp.IconButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblname = new System.Windows.Forms.Label();
            this.rjCircularPictureBox1 = new RJCodeAdvance.RJControls.RJCircularPictureBox();
            this.DropdownMenuStudData = new RJCodeAdvance.RJControls.RJDropdownMenu(this.components);
            this.viewStudentDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudentDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudData1 = new TimeMonitoringSystem.AddStudData();
            this.userDataInfo1 = new TimeMonitoringSystem.UserDataInfo();
            this.NavBar.SuspendLayout();
            this.ModuleBar.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rjCircularPictureBox1)).BeginInit();
            this.DropdownMenuStudData.SuspendLayout();
            this.SuspendLayout();
            // 
            // NavBar
            // 
            this.NavBar.BackColor = System.Drawing.Color.MediumPurple;
            this.NavBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NavBar.Controls.Add(this.iconButton8);
            this.NavBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.NavBar.Location = new System.Drawing.Point(193, 0);
            this.NavBar.Name = "NavBar";
            this.NavBar.Size = new System.Drawing.Size(811, 61);
            this.NavBar.TabIndex = 0;
            // 
            // iconButton8
            // 
            this.iconButton8.FlatAppearance.BorderSize = 0;
            this.iconButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton8.IconChar = FontAwesome.Sharp.IconChar.Bell;
            this.iconButton8.IconColor = System.Drawing.Color.Black;
            this.iconButton8.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.iconButton8.IconSize = 25;
            this.iconButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton8.Location = new System.Drawing.Point(6, 12);
            this.iconButton8.Name = "iconButton8";
            this.iconButton8.Size = new System.Drawing.Size(108, 44);
            this.iconButton8.TabIndex = 9;
            this.iconButton8.Text = "Notification";
            this.iconButton8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton8.UseVisualStyleBackColor = true;
            // 
            // ModuleBar
            // 
            this.ModuleBar.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.ModuleBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ModuleBar.Controls.Add(this.btnlogout);
            this.ModuleBar.Controls.Add(this.btnuserdata);
            this.ModuleBar.Controls.Add(this.btnstuddata);
            this.ModuleBar.Controls.Add(this.btndashboard);
            this.ModuleBar.Controls.Add(this.iconButton6);
            this.ModuleBar.Controls.Add(this.iconButton5);
            this.ModuleBar.Controls.Add(this.iconButton4);
            this.ModuleBar.Controls.Add(this.panel3);
            this.ModuleBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.ModuleBar.Location = new System.Drawing.Point(0, 0);
            this.ModuleBar.Name = "ModuleBar";
            this.ModuleBar.Size = new System.Drawing.Size(193, 569);
            this.ModuleBar.TabIndex = 1;
            // 
            // btnlogout
            // 
            this.btnlogout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnlogout.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnlogout.FlatAppearance.BorderSize = 0;
            this.btnlogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlogout.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.IconChar = FontAwesome.Sharp.IconChar.SignOutAlt;
            this.btnlogout.IconColor = System.Drawing.Color.Black;
            this.btnlogout.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnlogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnlogout.Location = new System.Drawing.Point(11, 516);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Size = new System.Drawing.Size(150, 40);
            this.btnlogout.TabIndex = 8;
            this.btnlogout.Text = "Log Out";
            this.btnlogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnlogout.UseVisualStyleBackColor = true;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // btnuserdata
            // 
            this.btnuserdata.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnuserdata.FlatAppearance.BorderSize = 0;
            this.btnuserdata.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnuserdata.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnuserdata.IconChar = FontAwesome.Sharp.IconChar.UserFriends;
            this.btnuserdata.IconColor = System.Drawing.Color.Black;
            this.btnuserdata.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnuserdata.IconSize = 40;
            this.btnuserdata.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnuserdata.Location = new System.Drawing.Point(12, 269);
            this.btnuserdata.Name = "btnuserdata";
            this.btnuserdata.Size = new System.Drawing.Size(150, 40);
            this.btnuserdata.TabIndex = 4;
            this.btnuserdata.Text = "Users Data";
            this.btnuserdata.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnuserdata.UseVisualStyleBackColor = true;
            this.btnuserdata.Click += new System.EventHandler(this.btnuserdata_Click);
            // 
            // btnstuddata
            // 
            this.btnstuddata.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnstuddata.FlatAppearance.BorderSize = 0;
            this.btnstuddata.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnstuddata.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstuddata.IconChar = FontAwesome.Sharp.IconChar.IdCard;
            this.btnstuddata.IconColor = System.Drawing.Color.Black;
            this.btnstuddata.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnstuddata.IconSize = 40;
            this.btnstuddata.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnstuddata.Location = new System.Drawing.Point(11, 223);
            this.btnstuddata.Name = "btnstuddata";
            this.btnstuddata.Size = new System.Drawing.Size(150, 40);
            this.btnstuddata.TabIndex = 3;
            this.btnstuddata.Text = "Students Data";
            this.btnstuddata.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnstuddata.UseVisualStyleBackColor = true;
            this.btnstuddata.Click += new System.EventHandler(this.btnstuddata_Click);
            // 
            // btndashboard
            // 
            this.btndashboard.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btndashboard.FlatAppearance.BorderSize = 0;
            this.btndashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndashboard.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndashboard.IconChar = FontAwesome.Sharp.IconChar.ChartBar;
            this.btndashboard.IconColor = System.Drawing.Color.Black;
            this.btndashboard.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btndashboard.IconSize = 40;
            this.btndashboard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndashboard.Location = new System.Drawing.Point(11, 177);
            this.btndashboard.Name = "btndashboard";
            this.btndashboard.Size = new System.Drawing.Size(150, 40);
            this.btndashboard.TabIndex = 2;
            this.btndashboard.Text = "Dashboard";
            this.btndashboard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btndashboard.UseVisualStyleBackColor = true;
            this.btndashboard.Click += new System.EventHandler(this.btndashboard_Click);
            // 
            // iconButton6
            // 
            this.iconButton6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.iconButton6.FlatAppearance.BorderSize = 0;
            this.iconButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton6.IconChar = FontAwesome.Sharp.IconChar.UserShield;
            this.iconButton6.IconColor = System.Drawing.Color.Black;
            this.iconButton6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton6.IconSize = 40;
            this.iconButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton6.Location = new System.Drawing.Point(11, 407);
            this.iconButton6.Name = "iconButton6";
            this.iconButton6.Size = new System.Drawing.Size(150, 40);
            this.iconButton6.TabIndex = 7;
            this.iconButton6.Text = "Admission";
            this.iconButton6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton6.UseVisualStyleBackColor = true;
            this.iconButton6.Click += new System.EventHandler(this.iconButton6_Click);
            // 
            // iconButton5
            // 
            this.iconButton5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.iconButton5.FlatAppearance.BorderSize = 0;
            this.iconButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton5.IconChar = FontAwesome.Sharp.IconChar.Info;
            this.iconButton5.IconColor = System.Drawing.Color.Black;
            this.iconButton5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton5.IconSize = 40;
            this.iconButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton5.Location = new System.Drawing.Point(11, 361);
            this.iconButton5.Name = "iconButton5";
            this.iconButton5.Size = new System.Drawing.Size(150, 40);
            this.iconButton5.TabIndex = 6;
            this.iconButton5.Text = "Guidance";
            this.iconButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton5.UseVisualStyleBackColor = true;
            this.iconButton5.Click += new System.EventHandler(this.iconButton5_Click);
            // 
            // iconButton4
            // 
            this.iconButton4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.iconButton4.FlatAppearance.BorderSize = 0;
            this.iconButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButton4.IconChar = FontAwesome.Sharp.IconChar.Database;
            this.iconButton4.IconColor = System.Drawing.Color.Black;
            this.iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton4.IconSize = 40;
            this.iconButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton4.Location = new System.Drawing.Point(11, 315);
            this.iconButton4.Name = "iconButton4";
            this.iconButton4.Size = new System.Drawing.Size(150, 40);
            this.iconButton4.TabIndex = 5;
            this.iconButton4.Text = "Faculty";
            this.iconButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButton4.UseVisualStyleBackColor = true;
            this.iconButton4.Click += new System.EventHandler(this.iconButton4_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panel3.Controls.Add(this.lblname);
            this.panel3.Controls.Add(this.rjCircularPictureBox1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(191, 171);
            this.panel3.TabIndex = 1;
            // 
            // lblname
            // 
            this.lblname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.ForeColor = System.Drawing.Color.White;
            this.lblname.Location = new System.Drawing.Point(11, 127);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(81, 20);
            this.lblname.TabIndex = 1;
            this.lblname.Text = "************";
            this.lblname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rjCircularPictureBox1
            // 
            this.rjCircularPictureBox1.BorderCapStyle = System.Drawing.Drawing2D.DashCap.Flat;
            this.rjCircularPictureBox1.BorderColor = System.Drawing.Color.RoyalBlue;
            this.rjCircularPictureBox1.BorderColor2 = System.Drawing.Color.HotPink;
            this.rjCircularPictureBox1.BorderLineStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.rjCircularPictureBox1.BorderSize = 2;
            this.rjCircularPictureBox1.GradientAngle = 50F;
            this.rjCircularPictureBox1.Location = new System.Drawing.Point(40, 11);
            this.rjCircularPictureBox1.Name = "rjCircularPictureBox1";
            this.rjCircularPictureBox1.Size = new System.Drawing.Size(103, 103);
            this.rjCircularPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rjCircularPictureBox1.TabIndex = 0;
            this.rjCircularPictureBox1.TabStop = false;
            // 
            // DropdownMenuStudData
            // 
            this.DropdownMenuStudData.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.DropdownMenuStudData.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DropdownMenuStudData.IsMainMenu = false;
            this.DropdownMenuStudData.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewStudentDataToolStripMenuItem,
            this.addStudentDataToolStripMenuItem});
            this.DropdownMenuStudData.MenuItemHeight = 25;
            this.DropdownMenuStudData.MenuItemTextColor = System.Drawing.Color.Black;
            this.DropdownMenuStudData.Name = "DropdownMenuStudData";
            this.DropdownMenuStudData.PrimaryColor = System.Drawing.Color.Empty;
            this.DropdownMenuStudData.Size = new System.Drawing.Size(202, 52);
            // 
            // viewStudentDataToolStripMenuItem
            // 
            this.viewStudentDataToolStripMenuItem.Name = "viewStudentDataToolStripMenuItem";
            this.viewStudentDataToolStripMenuItem.Size = new System.Drawing.Size(201, 24);
            this.viewStudentDataToolStripMenuItem.Text = "View Student Data";
            this.viewStudentDataToolStripMenuItem.Click += new System.EventHandler(this.viewStudentDataToolStripMenuItem_Click);
            // 
            // addStudentDataToolStripMenuItem
            // 
            this.addStudentDataToolStripMenuItem.Name = "addStudentDataToolStripMenuItem";
            this.addStudentDataToolStripMenuItem.Size = new System.Drawing.Size(201, 24);
            this.addStudentDataToolStripMenuItem.Text = "Add Student Data";
            this.addStudentDataToolStripMenuItem.Click += new System.EventHandler(this.addStudentDataToolStripMenuItem_Click);
            // 
            // addStudData1
            // 
            this.addStudData1.AllowDrop = true;
            this.addStudData1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addStudData1.AutoScroll = true;
            this.addStudData1.Location = new System.Drawing.Point(193, 61);
            this.addStudData1.Name = "addStudData1";
            this.addStudData1.Size = new System.Drawing.Size(811, 508);
            this.addStudData1.TabIndex = 3;
            this.addStudData1.Visible = false;
            // 
            // userDataInfo1
            // 
            this.userDataInfo1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.userDataInfo1.Location = new System.Drawing.Point(193, 61);
            this.userDataInfo1.Name = "userDataInfo1";
            this.userDataInfo1.Size = new System.Drawing.Size(811, 508);
            this.userDataInfo1.TabIndex = 2;
            this.userDataInfo1.Visible = false;
            // 
            // AccessForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1004, 569);
            this.Controls.Add(this.addStudData1);
            this.Controls.Add(this.userDataInfo1);
            this.Controls.Add(this.NavBar);
            this.Controls.Add(this.ModuleBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "AccessForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AccessForm";
            this.Load += new System.EventHandler(this.AccessForm_Load);
            this.NavBar.ResumeLayout(false);
            this.ModuleBar.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rjCircularPictureBox1)).EndInit();
            this.DropdownMenuStudData.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel NavBar;
        private System.Windows.Forms.Panel ModuleBar;
        private System.Windows.Forms.Panel panel3;
        private RJCodeAdvance.RJControls.RJCircularPictureBox rjCircularPictureBox1;
        private System.Windows.Forms.Label lblname;
        private FontAwesome.Sharp.IconButton btnlogout;
        private FontAwesome.Sharp.IconButton iconButton8;
        private RJCodeAdvance.RJControls.RJDropdownMenu DropdownMenuStudData;
        private System.Windows.Forms.ToolStripMenuItem viewStudentDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addStudentDataToolStripMenuItem;
        public FontAwesome.Sharp.IconButton iconButton4;
        public FontAwesome.Sharp.IconButton btnuserdata;
        public FontAwesome.Sharp.IconButton btnstuddata;
        public FontAwesome.Sharp.IconButton btndashboard;
        public FontAwesome.Sharp.IconButton iconButton6;
        public FontAwesome.Sharp.IconButton iconButton5;
        private UserDataInfo userDataInfo1;
        private AddStudData addStudData1;
    }
}