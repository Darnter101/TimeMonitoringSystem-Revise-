﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TimeMonitoringSystem
{
    public partial class FormLogIn : Form
    {
        //This is my connection string i have assigned the database file address path
        string connectionString = "server=localhost;port=3306;database=usersaccess;uid=root;pwd=;SslMode = none;";

        public FormLogIn()
        {
            InitializeComponent();
        }

        private void Btnlogin_Click(object sender, EventArgs e)
        {
           try
            {
                MySqlConnection conn = new MySqlConnection(connectionString);
                conn.Open();
                //This is my select query in which i am taking input from the user through windows forms
                MySqlCommand cmd = new MySqlCommand("select name, user_type from usersdata where username='" + txtuser.Texts + "' and password='" + txtpass.Texts + "'", conn);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                DataTable data = new DataTable();
                adapter.Fill(data);

                if (data.Rows.Count == 1)
                {
                    new Process(data.Rows[0][1].ToString()).ShowDialog();

                    if (data.Rows[0][1].ToString() == "Administrator")
                    {
                        new AccessForm(data.Rows[0][1].ToString()).Show();
                    }
                    else if (data.Rows[0][1].ToString() == "Assistant Principal") 
                    {
                        new AccessForm(data.Rows[0][1].ToString()).Show();
                    }
                    else if (data.Rows[0][1].ToString() == "Admission")
                    {
                        new AccessForm(data.Rows[0][1].ToString()).Show();
                    }
                    else if (data.Rows[0][1].ToString() == "Guidance")
                    {
                        new AccessForm(data.Rows[0][1].ToString()).Show();
                    }
                    else if (data.Rows[0][1].ToString() == "Faculty User")
                    {
                        new UserForm(data.Rows[0][1].ToString()).Show();
                    }
                    this.Hide();
                }
                else if (txtuser.Texts == "" || txtpass.Texts == "")
                {
                    lblmerror.Text = "Empty Failed!";
                    lblmerror.Show();
                    iconerror.Show();
                }
                else
                {
                    lblmerror.Text = "Login Denied!";
                    lblmerror.Show();
                    iconerror.Show();
                }
                conn.Close();
                txtuser.Texts = " ";
                txtpass.Texts = " ";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
