﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeMonitoringSystem
{
    public partial class AccessForm : Form
    {
        public AccessForm(string name)
        {
            InitializeComponent();
            lblname.Text = name;
            
        }

        public AccessForm()
        {
        }
       
        private void btnlogout_Click(object sender, EventArgs e)
        {
            new FormLogIn().Show();
            this.Hide();
        }

        private void btnuserdata_Click(object sender, EventArgs e)
        {
            SetActivePanel(userDataInfo1);
        }

        private void btndashboard_Click(object sender, EventArgs e)
        {
           // SetActivePanel(dashboard1);
        }

        public  void SetActivePanel(UserControl control)
        {
            // dashboard1.Visible = false;
            userDataInfo1.Visible = false;
            //viewUserData1.Visible = false;
           // viewFaculty1.Visible = false;
            addStudData1.Visible = false;
            //viewStudData1.Visible = false;
           // guidance1.Visible = false;
           // admission1.Visible = false;
            control.Visible = true;
        }

        private void btnstuddata_Click(object sender, EventArgs e)
        {
            DropdownMenuStudData.Show(btnstuddata, btnstuddata.Width, 0); 
        }

        private void AccessForm_Load(object sender, EventArgs e)
        {
            //SetActivePanel(dashboard1);
            if (lblname.Text == "Admission")
            {
                btnuserdata.Enabled = false;
                btndashboard.Enabled = false;
            }
            else if (lblname.Text == "Assistant Principal")
            {
                btnuserdata.Enabled = false;
            }
            else if (lblname.Text == "Guidance")
            {
                btnuserdata.Enabled = false;
            }
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
           // SetActivePanel(viewFaculty1);
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
           // SetActivePanel(guidance1);
        }

        private void iconButton6_Click(object sender, EventArgs e)
        {
            //SetActivePanel(admission1);
        }

        private void viewStudentDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
           // SetActivePanel(viewStudData1);
        }

        private void addStudentDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetActivePanel(addStudData1);
        }
    }
}
