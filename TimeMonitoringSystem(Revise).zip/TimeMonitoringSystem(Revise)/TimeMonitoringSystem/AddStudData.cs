﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeMonitoringSystem
{
    public partial class AddStudData : UserControl
    {
        public AddStudData()
        {
            InitializeComponent();
        }

        private void btnnewstud_Click(object sender, EventArgs e)
        {
            if(panelnewstud.Height == 77)
            {
                panelnewstud.Height = 1473;
                paneloldstud.Height = 77;
            }
            else
            {
                panelnewstud.Height = 77;
            }
        }

        private void btnoldstu_Click(object sender, EventArgs e)
        {
            if (paneloldstud.Height == 77)
            {
                paneloldstud.Height = 1473 ;
                panelnewstud.Height = 77;
            }
            else
            {
                paneloldstud.Height = 77;
            }
        }
    }
}
