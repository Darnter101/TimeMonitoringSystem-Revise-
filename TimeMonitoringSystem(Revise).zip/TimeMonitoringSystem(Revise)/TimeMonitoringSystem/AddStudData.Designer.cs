﻿
namespace TimeMonitoringSystem
{
    partial class AddStudData
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnnewstud = new FontAwesome.Sharp.IconButton();
            this.panelnewstud = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label64 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label34 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.paneloldstud = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.label92 = new System.Windows.Forms.Label();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label93 = new System.Windows.Forms.Label();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.label94 = new System.Windows.Forms.Label();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label95 = new System.Windows.Forms.Label();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.label96 = new System.Windows.Forms.Label();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label99 = new System.Windows.Forms.Label();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.label100 = new System.Windows.Forms.Label();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.label101 = new System.Windows.Forms.Label();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label103 = new System.Windows.Forms.Label();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.label104 = new System.Windows.Forms.Label();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.label105 = new System.Windows.Forms.Label();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.label106 = new System.Windows.Forms.Label();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.label107 = new System.Windows.Forms.Label();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.label108 = new System.Windows.Forms.Label();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.label109 = new System.Windows.Forms.Label();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.label110 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label111 = new System.Windows.Forms.Label();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.label112 = new System.Windows.Forms.Label();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.label113 = new System.Windows.Forms.Label();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.label114 = new System.Windows.Forms.Label();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.label115 = new System.Windows.Forms.Label();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.label116 = new System.Windows.Forms.Label();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.label119 = new System.Windows.Forms.Label();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.label120 = new System.Windows.Forms.Label();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.comboBox19 = new System.Windows.Forms.ComboBox();
            this.comboBox20 = new System.Windows.Forms.ComboBox();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.btnoldstu = new FontAwesome.Sharp.IconButton();
            this.panelnewstud.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.paneloldstud.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnnewstud
            // 
            this.btnnewstud.AutoSize = true;
            this.btnnewstud.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnnewstud.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnewstud.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.btnnewstud.IconColor = System.Drawing.Color.Black;
            this.btnnewstud.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnnewstud.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnnewstud.Location = new System.Drawing.Point(0, 0);
            this.btnnewstud.Name = "btnnewstud";
            this.btnnewstud.Size = new System.Drawing.Size(706, 77);
            this.btnnewstud.TabIndex = 0;
            this.btnnewstud.Text = "New Student";
            this.btnnewstud.UseVisualStyleBackColor = true;
            this.btnnewstud.Click += new System.EventHandler(this.btnnewstud_Click);
            // 
            // panelnewstud
            // 
            this.panelnewstud.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panelnewstud.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelnewstud.Controls.Add(this.button2);
            this.panelnewstud.Controls.Add(this.textBox43);
            this.panelnewstud.Controls.Add(this.label63);
            this.panelnewstud.Controls.Add(this.textBox36);
            this.panelnewstud.Controls.Add(this.label55);
            this.panelnewstud.Controls.Add(this.textBox37);
            this.panelnewstud.Controls.Add(this.label56);
            this.panelnewstud.Controls.Add(this.textBox38);
            this.panelnewstud.Controls.Add(this.label57);
            this.panelnewstud.Controls.Add(this.label58);
            this.panelnewstud.Controls.Add(this.textBox39);
            this.panelnewstud.Controls.Add(this.label59);
            this.panelnewstud.Controls.Add(this.textBox40);
            this.panelnewstud.Controls.Add(this.label60);
            this.panelnewstud.Controls.Add(this.textBox41);
            this.panelnewstud.Controls.Add(this.label61);
            this.panelnewstud.Controls.Add(this.textBox42);
            this.panelnewstud.Controls.Add(this.label62);
            this.panelnewstud.Controls.Add(this.textBox29);
            this.panelnewstud.Controls.Add(this.label47);
            this.panelnewstud.Controls.Add(this.textBox30);
            this.panelnewstud.Controls.Add(this.label48);
            this.panelnewstud.Controls.Add(this.textBox31);
            this.panelnewstud.Controls.Add(this.label49);
            this.panelnewstud.Controls.Add(this.label50);
            this.panelnewstud.Controls.Add(this.textBox32);
            this.panelnewstud.Controls.Add(this.label51);
            this.panelnewstud.Controls.Add(this.textBox33);
            this.panelnewstud.Controls.Add(this.label52);
            this.panelnewstud.Controls.Add(this.textBox34);
            this.panelnewstud.Controls.Add(this.label53);
            this.panelnewstud.Controls.Add(this.textBox35);
            this.panelnewstud.Controls.Add(this.label54);
            this.panelnewstud.Controls.Add(this.textBox26);
            this.panelnewstud.Controls.Add(this.label44);
            this.panelnewstud.Controls.Add(this.textBox27);
            this.panelnewstud.Controls.Add(this.label45);
            this.panelnewstud.Controls.Add(this.textBox28);
            this.panelnewstud.Controls.Add(this.label46);
            this.panelnewstud.Controls.Add(this.label43);
            this.panelnewstud.Controls.Add(this.textBox22);
            this.panelnewstud.Controls.Add(this.label39);
            this.panelnewstud.Controls.Add(this.textBox23);
            this.panelnewstud.Controls.Add(this.label40);
            this.panelnewstud.Controls.Add(this.textBox24);
            this.panelnewstud.Controls.Add(this.label41);
            this.panelnewstud.Controls.Add(this.textBox25);
            this.panelnewstud.Controls.Add(this.label42);
            this.panelnewstud.Controls.Add(this.panel5);
            this.panelnewstud.Controls.Add(this.comboBox10);
            this.panelnewstud.Controls.Add(this.label37);
            this.panelnewstud.Controls.Add(this.comboBox9);
            this.panelnewstud.Controls.Add(this.label36);
            this.panelnewstud.Controls.Add(this.comboBox8);
            this.panelnewstud.Controls.Add(this.label35);
            this.panelnewstud.Controls.Add(this.dateTimePicker2);
            this.panelnewstud.Controls.Add(this.label34);
            this.panelnewstud.Controls.Add(this.comboBox7);
            this.panelnewstud.Controls.Add(this.textBox20);
            this.panelnewstud.Controls.Add(this.label31);
            this.panelnewstud.Controls.Add(this.textBox21);
            this.panelnewstud.Controls.Add(this.label32);
            this.panelnewstud.Controls.Add(this.label33);
            this.panelnewstud.Controls.Add(this.panel4);
            this.panelnewstud.Controls.Add(this.textBox19);
            this.panelnewstud.Controls.Add(this.label29);
            this.panelnewstud.Controls.Add(this.textBox17);
            this.panelnewstud.Controls.Add(this.label22);
            this.panelnewstud.Controls.Add(this.textBox18);
            this.panelnewstud.Controls.Add(this.label25);
            this.panelnewstud.Controls.Add(this.panel1);
            this.panelnewstud.Controls.Add(this.textBox11);
            this.panelnewstud.Controls.Add(this.label20);
            this.panelnewstud.Controls.Add(this.textBox10);
            this.panelnewstud.Controls.Add(this.label19);
            this.panelnewstud.Controls.Add(this.textBox12);
            this.panelnewstud.Controls.Add(this.label23);
            this.panelnewstud.Controls.Add(this.textBox13);
            this.panelnewstud.Controls.Add(this.label24);
            this.panelnewstud.Controls.Add(this.textBox14);
            this.panelnewstud.Controls.Add(this.label26);
            this.panelnewstud.Controls.Add(this.textBox15);
            this.panelnewstud.Controls.Add(this.label27);
            this.panelnewstud.Controls.Add(this.textBox16);
            this.panelnewstud.Controls.Add(this.label28);
            this.panelnewstud.Controls.Add(this.panel3);
            this.panelnewstud.Controls.Add(this.textBox9);
            this.panelnewstud.Controls.Add(this.label17);
            this.panelnewstud.Controls.Add(this.dateTimePicker1);
            this.panelnewstud.Controls.Add(this.label16);
            this.panelnewstud.Controls.Add(this.textBox6);
            this.panelnewstud.Controls.Add(this.label15);
            this.panelnewstud.Controls.Add(this.comboBox6);
            this.panelnewstud.Controls.Add(this.label14);
            this.panelnewstud.Controls.Add(this.comboBox5);
            this.panelnewstud.Controls.Add(this.textBox8);
            this.panelnewstud.Controls.Add(this.label13);
            this.panelnewstud.Controls.Add(this.textBox7);
            this.panelnewstud.Controls.Add(this.label12);
            this.panelnewstud.Controls.Add(this.label11);
            this.panelnewstud.Controls.Add(this.textBox5);
            this.panelnewstud.Controls.Add(this.label10);
            this.panelnewstud.Controls.Add(this.textBox4);
            this.panelnewstud.Controls.Add(this.label9);
            this.panelnewstud.Controls.Add(this.textBox3);
            this.panelnewstud.Controls.Add(this.panel2);
            this.panelnewstud.Controls.Add(this.label8);
            this.panelnewstud.Controls.Add(this.label7);
            this.panelnewstud.Controls.Add(this.label6);
            this.panelnewstud.Controls.Add(this.label5);
            this.panelnewstud.Controls.Add(this.label3);
            this.panelnewstud.Controls.Add(this.textBox2);
            this.panelnewstud.Controls.Add(this.comboBox4);
            this.panelnewstud.Controls.Add(this.comboBox3);
            this.panelnewstud.Controls.Add(this.comboBox2);
            this.panelnewstud.Controls.Add(this.comboBox1);
            this.panelnewstud.Controls.Add(this.label1);
            this.panelnewstud.Controls.Add(this.label2);
            this.panelnewstud.Controls.Add(this.textBox1);
            this.panelnewstud.Controls.Add(this.btnnewstud);
            this.panelnewstud.Location = new System.Drawing.Point(17, 105);
            this.panelnewstud.Name = "panelnewstud";
            this.panelnewstud.Size = new System.Drawing.Size(706, 77);
            this.panelnewstud.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Agency FB", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(444, 1425);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(235, 36);
            this.button2.TabIndex = 132;
            this.button2.Text = "Proceed to Register Data";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox43
            // 
            this.textBox43.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox43.Location = new System.Drawing.Point(570, 1384);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(109, 25);
            this.textBox43.TabIndex = 130;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(566, 1362);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(75, 19);
            this.label63.TabIndex = 129;
            this.label63.Text = "Relationship";
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox36.Location = new System.Drawing.Point(402, 1384);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(137, 25);
            this.textBox36.TabIndex = 128;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(398, 1362);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(68, 19);
            this.label55.TabIndex = 127;
            this.label55.Text = "Occupation";
            // 
            // textBox37
            // 
            this.textBox37.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox37.Location = new System.Drawing.Point(163, 1384);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(223, 25);
            this.textBox37.TabIndex = 126;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(159, 1362);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(46, 19);
            this.label56.TabIndex = 125;
            this.label56.Text = "Email *";
            // 
            // textBox38
            // 
            this.textBox38.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox38.Location = new System.Drawing.Point(13, 1384);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(136, 25);
            this.textBox38.TabIndex = 124;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(9, 1362);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(94, 19);
            this.label57.TabIndex = 123;
            this.label57.Text = "Mobile Number *";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(9, 1285);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(156, 23);
            this.label58.TabIndex = 122;
            this.label58.Text = "Guardian\'s Information";
            // 
            // textBox39
            // 
            this.textBox39.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox39.Location = new System.Drawing.Point(369, 1330);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(143, 25);
            this.textBox39.TabIndex = 121;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(365, 1308);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(75, 19);
            this.label59.TabIndex = 120;
            this.label59.Text = "Last Name: *";
            // 
            // textBox40
            // 
            this.textBox40.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox40.Location = new System.Drawing.Point(536, 1330);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(143, 25);
            this.textBox40.TabIndex = 119;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(532, 1308);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(76, 19);
            this.label60.TabIndex = 118;
            this.label60.Text = "Suffix Name:";
            // 
            // textBox41
            // 
            this.textBox41.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox41.Location = new System.Drawing.Point(201, 1330);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(144, 25);
            this.textBox41.TabIndex = 117;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(197, 1308);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(79, 19);
            this.label61.TabIndex = 116;
            this.label61.Text = "Middle Name:";
            // 
            // textBox42
            // 
            this.textBox42.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox42.Location = new System.Drawing.Point(13, 1330);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(167, 25);
            this.textBox42.TabIndex = 115;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(9, 1308);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(76, 19);
            this.label62.TabIndex = 114;
            this.label62.Text = "First Name: *";
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(537, 1247);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(137, 25);
            this.textBox29.TabIndex = 113;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(533, 1225);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(68, 19);
            this.label47.TabIndex = 112;
            this.label47.Text = "Occupation";
            // 
            // textBox30
            // 
            this.textBox30.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox30.Location = new System.Drawing.Point(202, 1247);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(311, 25);
            this.textBox30.TabIndex = 111;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(198, 1225);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(46, 19);
            this.label48.TabIndex = 110;
            this.label48.Text = "Email *";
            // 
            // textBox31
            // 
            this.textBox31.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox31.Location = new System.Drawing.Point(14, 1247);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(155, 25);
            this.textBox31.TabIndex = 109;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(10, 1225);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(94, 19);
            this.label49.TabIndex = 108;
            this.label49.Text = "Mobile Number *";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(10, 1148);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(142, 23);
            this.label50.TabIndex = 107;
            this.label50.Text = "Mother\'s Information";
            // 
            // textBox32
            // 
            this.textBox32.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox32.Location = new System.Drawing.Point(370, 1193);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(143, 25);
            this.textBox32.TabIndex = 106;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(366, 1171);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(75, 19);
            this.label51.TabIndex = 105;
            this.label51.Text = "Last Name: *";
            // 
            // textBox33
            // 
            this.textBox33.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(537, 1193);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(143, 25);
            this.textBox33.TabIndex = 104;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(533, 1171);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(76, 19);
            this.label52.TabIndex = 103;
            this.label52.Text = "Suffix Name:";
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox34.Location = new System.Drawing.Point(202, 1193);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(144, 25);
            this.textBox34.TabIndex = 102;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(198, 1171);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(79, 19);
            this.label53.TabIndex = 101;
            this.label53.Text = "Middle Name:";
            // 
            // textBox35
            // 
            this.textBox35.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox35.Location = new System.Drawing.Point(14, 1193);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(167, 25);
            this.textBox35.TabIndex = 100;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(10, 1171);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(76, 19);
            this.label54.TabIndex = 99;
            this.label54.Text = "First Name: *";
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox26.Location = new System.Drawing.Point(537, 1108);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(137, 25);
            this.textBox26.TabIndex = 98;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(533, 1086);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(68, 19);
            this.label44.TabIndex = 97;
            this.label44.Text = "Occupation";
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox27.Location = new System.Drawing.Point(202, 1108);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(311, 25);
            this.textBox27.TabIndex = 96;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(198, 1086);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(46, 19);
            this.label45.TabIndex = 95;
            this.label45.Text = "Email *";
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(14, 1108);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(155, 25);
            this.textBox28.TabIndex = 94;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(10, 1086);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(94, 19);
            this.label46.TabIndex = 93;
            this.label46.Text = "Mobile Number *";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(10, 1009);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(139, 23);
            this.label43.TabIndex = 92;
            this.label43.Text = "Father\'s Information";
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox22.Location = new System.Drawing.Point(370, 1054);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(143, 25);
            this.textBox22.TabIndex = 91;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(366, 1032);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(75, 19);
            this.label39.TabIndex = 90;
            this.label39.Text = "Last Name: *";
            // 
            // textBox23
            // 
            this.textBox23.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(537, 1054);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(143, 25);
            this.textBox23.TabIndex = 89;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(533, 1032);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(76, 19);
            this.label40.TabIndex = 88;
            this.label40.Text = "Suffix Name:";
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox24.Location = new System.Drawing.Point(202, 1054);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(144, 25);
            this.textBox24.TabIndex = 87;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(198, 1032);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(79, 19);
            this.label41.TabIndex = 86;
            this.label41.Text = "Middle Name:";
            // 
            // textBox25
            // 
            this.textBox25.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(14, 1054);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(167, 25);
            this.textBox25.TabIndex = 85;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(10, 1032);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(76, 19);
            this.label42.TabIndex = 84;
            this.label42.Text = "First Name: *";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Gainsboro;
            this.panel5.Controls.Add(this.label64);
            this.panel5.Controls.Add(this.label38);
            this.panel5.Location = new System.Drawing.Point(3, 968);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(700, 38);
            this.panel5.TabIndex = 83;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(343, 9);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(334, 15);
            this.label64.TabIndex = 12;
            this.label64.Text = "* Please complete at least one parent / guardian information";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(7, 9);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(189, 19);
            this.label38.TabIndex = 11;
            this.label38.Text = "Parents / Guardian\'s Information  ";
            // 
            // comboBox10
            // 
            this.comboBox10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(543, 927);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(137, 25);
            this.comboBox10.TabIndex = 82;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(539, 905);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(35, 19);
            this.label37.TabIndex = 81;
            this.label37.Text = "Term";
            // 
            // comboBox9
            // 
            this.comboBox9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(384, 927);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(137, 25);
            this.comboBox9.TabIndex = 80;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(380, 905);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(114, 19);
            this.label36.TabIndex = 79;
            this.label36.Text = "Year Level / Grade *:";
            // 
            // comboBox8
            // 
            this.comboBox8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(232, 927);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(137, 25);
            this.comboBox8.TabIndex = 78;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(228, 905);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(78, 19);
            this.label35.TabIndex = 77;
            this.label35.Text = "School Year *";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CalendarFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Location = new System.Drawing.Point(14, 932);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(202, 20);
            this.dateTimePicker2.TabIndex = 76;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(10, 905);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(111, 19);
            this.label34.TabIndex = 75;
            this.label34.Text = "Date of Graduation:";
            // 
            // comboBox7
            // 
            this.comboBox7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(14, 858);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(137, 25);
            this.comboBox7.TabIndex = 74;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox20.Location = new System.Drawing.Point(507, 877);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(173, 25);
            this.textBox20.TabIndex = 73;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(503, 836);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(146, 38);
            this.label31.TabIndex = 72;
            this.label31.Text = "Program / Track & Strand / \r\nSpecialization";
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox21.Location = new System.Drawing.Point(168, 858);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(323, 25);
            this.textBox21.TabIndex = 71;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(164, 836);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(98, 19);
            this.label32.TabIndex = 70;
            this.label32.Text = "Name of School:*";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(10, 836);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(81, 19);
            this.label33.TabIndex = 68;
            this.label33.Text = "School Type: *";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gainsboro;
            this.panel4.Controls.Add(this.label30);
            this.panel4.Location = new System.Drawing.Point(3, 795);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(700, 38);
            this.panel4.TabIndex = 67;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(7, 9);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(178, 19);
            this.label30.TabIndex = 11;
            this.label30.Text = "Current or Last School Attended";
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(384, 758);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(296, 25);
            this.textBox19.TabIndex = 66;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(380, 736);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(94, 19);
            this.label29.TabIndex = 65;
            this.label29.Text = "Email Address: *";
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(202, 758);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(144, 25);
            this.textBox17.TabIndex = 64;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(198, 736);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(72, 19);
            this.label22.TabIndex = 63;
            this.label22.Text = "Mobile No.: *";
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(14, 758);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(155, 25);
            this.textBox18.TabIndex = 62;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(10, 736);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(84, 19);
            this.label25.TabIndex = 61;
            this.label25.Text = "Telephone No.:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.label21);
            this.panel1.Location = new System.Drawing.Point(3, 695);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(700, 38);
            this.panel1.TabIndex = 60;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(7, 9);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(90, 19);
            this.label21.TabIndex = 11;
            this.label21.Text = "Contact Details";
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(578, 654);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(102, 25);
            this.textBox11.TabIndex = 59;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(574, 632);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 19);
            this.label20.TabIndex = 58;
            this.label20.Text = "Zip Code:";
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(332, 654);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(223, 25);
            this.textBox10.TabIndex = 57;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(328, 632);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 19);
            this.label19.TabIndex = 56;
            this.label19.Text = "Province:";
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(370, 596);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(143, 25);
            this.textBox12.TabIndex = 48;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(366, 555);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(125, 38);
            this.label23.TabIndex = 47;
            this.label23.Text = "Subdivision / Village / \r\nBldg.:";
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(537, 577);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(143, 25);
            this.textBox13.TabIndex = 46;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(533, 555);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(63, 19);
            this.label24.TabIndex = 45;
            this.label24.Text = "Barangay:";
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(14, 654);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(293, 25);
            this.textBox14.TabIndex = 43;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(10, 632);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(113, 19);
            this.label26.TabIndex = 42;
            this.label26.Text = "City / Municipality: *";
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(202, 577);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(144, 25);
            this.textBox15.TabIndex = 41;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(198, 555);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(51, 19);
            this.label27.TabIndex = 40;
            this.label27.Text = "Street: *";
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(14, 577);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(167, 25);
            this.textBox16.TabIndex = 39;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(10, 555);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(102, 19);
            this.label28.TabIndex = 38;
            this.label28.Text = "Street # / Unit #: *";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.Controls.Add(this.label18);
            this.panel3.Location = new System.Drawing.Point(3, 511);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(700, 38);
            this.panel3.TabIndex = 37;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(7, 9);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(163, 19);
            this.label18.TabIndex = 11;
            this.label18.Text = "Current / Permanent Address";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(457, 469);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(223, 25);
            this.textBox9.TabIndex = 36;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(453, 447);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 19);
            this.label17.TabIndex = 35;
            this.label17.Text = "Religion: *";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(478, 417);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(202, 20);
            this.dateTimePicker1.TabIndex = 34;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(474, 390);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(85, 19);
            this.label16.TabIndex = 33;
            this.label16.Text = "Date of Birth: *";
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(332, 412);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(125, 25);
            this.textBox6.TabIndex = 32;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(328, 390);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 19);
            this.label15.TabIndex = 31;
            this.label15.Text = "Citizenship: *";
            // 
            // comboBox6
            // 
            this.comboBox6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(165, 412);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(142, 25);
            this.comboBox6.TabIndex = 30;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(166, 390);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 19);
            this.label14.TabIndex = 29;
            this.label14.Text = "Status: *";
            // 
            // comboBox5
            // 
            this.comboBox5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(9, 412);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(142, 25);
            this.comboBox5.TabIndex = 28;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(370, 357);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(143, 25);
            this.textBox8.TabIndex = 27;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(366, 335);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 19);
            this.label13.TabIndex = 26;
            this.label13.Text = "Last Name: *";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(537, 357);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(143, 25);
            this.textBox7.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(533, 335);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 19);
            this.label12.TabIndex = 24;
            this.label12.Text = "Suffix Name:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(10, 390);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 19);
            this.label11.TabIndex = 22;
            this.label11.Text = "Gender: *";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(14, 469);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(427, 25);
            this.textBox5.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(10, 447);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 19);
            this.label10.TabIndex = 20;
            this.label10.Text = "Birthplace: *";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(202, 357);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(144, 25);
            this.textBox4.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(198, 335);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 19);
            this.label9.TabIndex = 18;
            this.label9.Text = "Middle Name:";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(14, 357);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(167, 25);
            this.textBox3.TabIndex = 17;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(3, 294);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(700, 38);
            this.panel2.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 19);
            this.label4.TabIndex = 11;
            this.label4.Text = "Student\'s Information";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(53, 149);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 19);
            this.label8.TabIndex = 15;
            this.label8.Text = "Term: *";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(53, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 19);
            this.label7.TabIndex = 14;
            this.label7.Text = "Grade: *";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(53, 211);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 19);
            this.label6.TabIndex = 13;
            this.label6.Text = "Senior High Program: *";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(53, 242);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 38);
            this.label5.TabIndex = 12;
            this.label5.Text = "Learners Reference \r\n                     Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 335);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 19);
            this.label3.TabIndex = 10;
            this.label3.Text = "First Name: *";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(207, 242);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(432, 25);
            this.textBox2.TabIndex = 9;
            // 
            // comboBox4
            // 
            this.comboBox4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(207, 149);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(432, 25);
            this.comboBox4.TabIndex = 8;
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(207, 180);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(432, 25);
            this.comboBox3.TabIndex = 7;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(207, 211);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(432, 25);
            this.comboBox2.TabIndex = 6;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(207, 118);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(432, 25);
            this.comboBox1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 19);
            this.label1.TabIndex = 4;
            this.label1.Text = "School Year: *";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(53, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Admit Type: *";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(207, 87);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(432, 25);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "New Student";
            // 
            // paneloldstud
            // 
            this.paneloldstud.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.paneloldstud.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.paneloldstud.Controls.Add(this.button1);
            this.paneloldstud.Controls.Add(this.textBox44);
            this.paneloldstud.Controls.Add(this.label65);
            this.paneloldstud.Controls.Add(this.textBox45);
            this.paneloldstud.Controls.Add(this.label66);
            this.paneloldstud.Controls.Add(this.textBox46);
            this.paneloldstud.Controls.Add(this.label67);
            this.paneloldstud.Controls.Add(this.textBox47);
            this.paneloldstud.Controls.Add(this.label68);
            this.paneloldstud.Controls.Add(this.label69);
            this.paneloldstud.Controls.Add(this.textBox48);
            this.paneloldstud.Controls.Add(this.label70);
            this.paneloldstud.Controls.Add(this.textBox49);
            this.paneloldstud.Controls.Add(this.label71);
            this.paneloldstud.Controls.Add(this.textBox50);
            this.paneloldstud.Controls.Add(this.label72);
            this.paneloldstud.Controls.Add(this.textBox51);
            this.paneloldstud.Controls.Add(this.label73);
            this.paneloldstud.Controls.Add(this.textBox52);
            this.paneloldstud.Controls.Add(this.label74);
            this.paneloldstud.Controls.Add(this.textBox53);
            this.paneloldstud.Controls.Add(this.label75);
            this.paneloldstud.Controls.Add(this.textBox54);
            this.paneloldstud.Controls.Add(this.label76);
            this.paneloldstud.Controls.Add(this.label77);
            this.paneloldstud.Controls.Add(this.textBox55);
            this.paneloldstud.Controls.Add(this.label78);
            this.paneloldstud.Controls.Add(this.textBox56);
            this.paneloldstud.Controls.Add(this.label79);
            this.paneloldstud.Controls.Add(this.textBox57);
            this.paneloldstud.Controls.Add(this.label80);
            this.paneloldstud.Controls.Add(this.textBox58);
            this.paneloldstud.Controls.Add(this.label81);
            this.paneloldstud.Controls.Add(this.textBox59);
            this.paneloldstud.Controls.Add(this.label82);
            this.paneloldstud.Controls.Add(this.textBox60);
            this.paneloldstud.Controls.Add(this.label83);
            this.paneloldstud.Controls.Add(this.textBox61);
            this.paneloldstud.Controls.Add(this.label84);
            this.paneloldstud.Controls.Add(this.label85);
            this.paneloldstud.Controls.Add(this.textBox62);
            this.paneloldstud.Controls.Add(this.label86);
            this.paneloldstud.Controls.Add(this.textBox63);
            this.paneloldstud.Controls.Add(this.label87);
            this.paneloldstud.Controls.Add(this.textBox64);
            this.paneloldstud.Controls.Add(this.label88);
            this.paneloldstud.Controls.Add(this.textBox65);
            this.paneloldstud.Controls.Add(this.label89);
            this.paneloldstud.Controls.Add(this.panel7);
            this.paneloldstud.Controls.Add(this.comboBox11);
            this.paneloldstud.Controls.Add(this.label92);
            this.paneloldstud.Controls.Add(this.comboBox12);
            this.paneloldstud.Controls.Add(this.label93);
            this.paneloldstud.Controls.Add(this.comboBox13);
            this.paneloldstud.Controls.Add(this.label94);
            this.paneloldstud.Controls.Add(this.dateTimePicker3);
            this.paneloldstud.Controls.Add(this.label95);
            this.paneloldstud.Controls.Add(this.comboBox14);
            this.paneloldstud.Controls.Add(this.textBox66);
            this.paneloldstud.Controls.Add(this.label96);
            this.paneloldstud.Controls.Add(this.textBox67);
            this.paneloldstud.Controls.Add(this.label97);
            this.paneloldstud.Controls.Add(this.label98);
            this.paneloldstud.Controls.Add(this.panel8);
            this.paneloldstud.Controls.Add(this.textBox68);
            this.paneloldstud.Controls.Add(this.label100);
            this.paneloldstud.Controls.Add(this.textBox69);
            this.paneloldstud.Controls.Add(this.label101);
            this.paneloldstud.Controls.Add(this.textBox70);
            this.paneloldstud.Controls.Add(this.label102);
            this.paneloldstud.Controls.Add(this.panel9);
            this.paneloldstud.Controls.Add(this.textBox71);
            this.paneloldstud.Controls.Add(this.label104);
            this.paneloldstud.Controls.Add(this.textBox72);
            this.paneloldstud.Controls.Add(this.label105);
            this.paneloldstud.Controls.Add(this.textBox73);
            this.paneloldstud.Controls.Add(this.label106);
            this.paneloldstud.Controls.Add(this.textBox74);
            this.paneloldstud.Controls.Add(this.label107);
            this.paneloldstud.Controls.Add(this.textBox75);
            this.paneloldstud.Controls.Add(this.label108);
            this.paneloldstud.Controls.Add(this.textBox76);
            this.paneloldstud.Controls.Add(this.label109);
            this.paneloldstud.Controls.Add(this.textBox77);
            this.paneloldstud.Controls.Add(this.label110);
            this.paneloldstud.Controls.Add(this.panel10);
            this.paneloldstud.Controls.Add(this.textBox78);
            this.paneloldstud.Controls.Add(this.label112);
            this.paneloldstud.Controls.Add(this.dateTimePicker4);
            this.paneloldstud.Controls.Add(this.label113);
            this.paneloldstud.Controls.Add(this.textBox79);
            this.paneloldstud.Controls.Add(this.label114);
            this.paneloldstud.Controls.Add(this.comboBox15);
            this.paneloldstud.Controls.Add(this.label115);
            this.paneloldstud.Controls.Add(this.comboBox16);
            this.paneloldstud.Controls.Add(this.textBox80);
            this.paneloldstud.Controls.Add(this.label116);
            this.paneloldstud.Controls.Add(this.textBox81);
            this.paneloldstud.Controls.Add(this.label117);
            this.paneloldstud.Controls.Add(this.label118);
            this.paneloldstud.Controls.Add(this.textBox82);
            this.paneloldstud.Controls.Add(this.label119);
            this.paneloldstud.Controls.Add(this.textBox83);
            this.paneloldstud.Controls.Add(this.label120);
            this.paneloldstud.Controls.Add(this.textBox84);
            this.paneloldstud.Controls.Add(this.panel11);
            this.paneloldstud.Controls.Add(this.label122);
            this.paneloldstud.Controls.Add(this.label123);
            this.paneloldstud.Controls.Add(this.label124);
            this.paneloldstud.Controls.Add(this.label125);
            this.paneloldstud.Controls.Add(this.label126);
            this.paneloldstud.Controls.Add(this.textBox85);
            this.paneloldstud.Controls.Add(this.comboBox17);
            this.paneloldstud.Controls.Add(this.comboBox18);
            this.paneloldstud.Controls.Add(this.comboBox19);
            this.paneloldstud.Controls.Add(this.comboBox20);
            this.paneloldstud.Controls.Add(this.label127);
            this.paneloldstud.Controls.Add(this.label128);
            this.paneloldstud.Controls.Add(this.textBox86);
            this.paneloldstud.Controls.Add(this.btnoldstu);
            this.paneloldstud.Location = new System.Drawing.Point(17, 18);
            this.paneloldstud.Name = "paneloldstud";
            this.paneloldstud.Size = new System.Drawing.Size(706, 77);
            this.paneloldstud.TabIndex = 131;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Agency FB", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(445, 1425);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(235, 36);
            this.button1.TabIndex = 131;
            this.button1.Text = "Proceed to Register Data";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox44
            // 
            this.textBox44.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox44.Location = new System.Drawing.Point(570, 1384);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(109, 25);
            this.textBox44.TabIndex = 130;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(566, 1362);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(75, 19);
            this.label65.TabIndex = 129;
            this.label65.Text = "Relationship";
            // 
            // textBox45
            // 
            this.textBox45.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox45.Location = new System.Drawing.Point(402, 1384);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(137, 25);
            this.textBox45.TabIndex = 128;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(398, 1362);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(68, 19);
            this.label66.TabIndex = 127;
            this.label66.Text = "Occupation";
            // 
            // textBox46
            // 
            this.textBox46.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox46.Location = new System.Drawing.Point(163, 1384);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(223, 25);
            this.textBox46.TabIndex = 126;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(159, 1362);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(46, 19);
            this.label67.TabIndex = 125;
            this.label67.Text = "Email *";
            // 
            // textBox47
            // 
            this.textBox47.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox47.Location = new System.Drawing.Point(13, 1384);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(136, 25);
            this.textBox47.TabIndex = 124;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(9, 1362);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(94, 19);
            this.label68.TabIndex = 123;
            this.label68.Text = "Mobile Number *";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(9, 1285);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(156, 23);
            this.label69.TabIndex = 122;
            this.label69.Text = "Guardian\'s Information";
            // 
            // textBox48
            // 
            this.textBox48.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox48.Location = new System.Drawing.Point(369, 1330);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(143, 25);
            this.textBox48.TabIndex = 121;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(365, 1308);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(75, 19);
            this.label70.TabIndex = 120;
            this.label70.Text = "Last Name: *";
            // 
            // textBox49
            // 
            this.textBox49.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox49.Location = new System.Drawing.Point(536, 1330);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(143, 25);
            this.textBox49.TabIndex = 119;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(532, 1308);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(76, 19);
            this.label71.TabIndex = 118;
            this.label71.Text = "Suffix Name:";
            // 
            // textBox50
            // 
            this.textBox50.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox50.Location = new System.Drawing.Point(201, 1330);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(144, 25);
            this.textBox50.TabIndex = 117;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(197, 1308);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(79, 19);
            this.label72.TabIndex = 116;
            this.label72.Text = "Middle Name:";
            // 
            // textBox51
            // 
            this.textBox51.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox51.Location = new System.Drawing.Point(13, 1330);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(167, 25);
            this.textBox51.TabIndex = 115;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(9, 1308);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(76, 19);
            this.label73.TabIndex = 114;
            this.label73.Text = "First Name: *";
            // 
            // textBox52
            // 
            this.textBox52.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox52.Location = new System.Drawing.Point(537, 1247);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(137, 25);
            this.textBox52.TabIndex = 113;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(533, 1225);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(68, 19);
            this.label74.TabIndex = 112;
            this.label74.Text = "Occupation";
            // 
            // textBox53
            // 
            this.textBox53.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox53.Location = new System.Drawing.Point(202, 1247);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(311, 25);
            this.textBox53.TabIndex = 111;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(198, 1225);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(46, 19);
            this.label75.TabIndex = 110;
            this.label75.Text = "Email *";
            // 
            // textBox54
            // 
            this.textBox54.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox54.Location = new System.Drawing.Point(14, 1247);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(155, 25);
            this.textBox54.TabIndex = 109;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(10, 1225);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(94, 19);
            this.label76.TabIndex = 108;
            this.label76.Text = "Mobile Number *";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(10, 1148);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(142, 23);
            this.label77.TabIndex = 107;
            this.label77.Text = "Mother\'s Information";
            // 
            // textBox55
            // 
            this.textBox55.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox55.Location = new System.Drawing.Point(370, 1193);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(143, 25);
            this.textBox55.TabIndex = 106;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(366, 1171);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(75, 19);
            this.label78.TabIndex = 105;
            this.label78.Text = "Last Name: *";
            // 
            // textBox56
            // 
            this.textBox56.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox56.Location = new System.Drawing.Point(537, 1193);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(143, 25);
            this.textBox56.TabIndex = 104;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(533, 1171);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(76, 19);
            this.label79.TabIndex = 103;
            this.label79.Text = "Suffix Name:";
            // 
            // textBox57
            // 
            this.textBox57.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox57.Location = new System.Drawing.Point(202, 1193);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(144, 25);
            this.textBox57.TabIndex = 102;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(198, 1171);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(79, 19);
            this.label80.TabIndex = 101;
            this.label80.Text = "Middle Name:";
            // 
            // textBox58
            // 
            this.textBox58.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox58.Location = new System.Drawing.Point(14, 1193);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(167, 25);
            this.textBox58.TabIndex = 100;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(10, 1171);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(76, 19);
            this.label81.TabIndex = 99;
            this.label81.Text = "First Name: *";
            // 
            // textBox59
            // 
            this.textBox59.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox59.Location = new System.Drawing.Point(537, 1108);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(137, 25);
            this.textBox59.TabIndex = 98;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(533, 1086);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(68, 19);
            this.label82.TabIndex = 97;
            this.label82.Text = "Occupation";
            // 
            // textBox60
            // 
            this.textBox60.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox60.Location = new System.Drawing.Point(202, 1108);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(311, 25);
            this.textBox60.TabIndex = 96;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(198, 1086);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(46, 19);
            this.label83.TabIndex = 95;
            this.label83.Text = "Email *";
            // 
            // textBox61
            // 
            this.textBox61.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox61.Location = new System.Drawing.Point(14, 1108);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(155, 25);
            this.textBox61.TabIndex = 94;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(10, 1086);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(94, 19);
            this.label84.TabIndex = 93;
            this.label84.Text = "Mobile Number *";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(10, 1009);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(139, 23);
            this.label85.TabIndex = 92;
            this.label85.Text = "Father\'s Information";
            // 
            // textBox62
            // 
            this.textBox62.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox62.Location = new System.Drawing.Point(370, 1054);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(143, 25);
            this.textBox62.TabIndex = 91;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(366, 1032);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(75, 19);
            this.label86.TabIndex = 90;
            this.label86.Text = "Last Name: *";
            // 
            // textBox63
            // 
            this.textBox63.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox63.Location = new System.Drawing.Point(537, 1054);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(143, 25);
            this.textBox63.TabIndex = 89;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(533, 1032);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(76, 19);
            this.label87.TabIndex = 88;
            this.label87.Text = "Suffix Name:";
            // 
            // textBox64
            // 
            this.textBox64.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox64.Location = new System.Drawing.Point(202, 1054);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(144, 25);
            this.textBox64.TabIndex = 87;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(198, 1032);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(79, 19);
            this.label88.TabIndex = 86;
            this.label88.Text = "Middle Name:";
            // 
            // textBox65
            // 
            this.textBox65.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox65.Location = new System.Drawing.Point(14, 1054);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(167, 25);
            this.textBox65.TabIndex = 85;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(10, 1032);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(76, 19);
            this.label89.TabIndex = 84;
            this.label89.Text = "First Name: *";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Gainsboro;
            this.panel7.Controls.Add(this.label90);
            this.panel7.Controls.Add(this.label91);
            this.panel7.Location = new System.Drawing.Point(3, 968);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(700, 38);
            this.panel7.TabIndex = 83;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(343, 9);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(334, 15);
            this.label90.TabIndex = 12;
            this.label90.Text = "* Please complete at least one parent / guardian information";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(7, 9);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(189, 19);
            this.label91.TabIndex = 11;
            this.label91.Text = "Parents / Guardian\'s Information  ";
            // 
            // comboBox11
            // 
            this.comboBox11.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Location = new System.Drawing.Point(543, 927);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(137, 25);
            this.comboBox11.TabIndex = 82;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(539, 905);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(35, 19);
            this.label92.TabIndex = 81;
            this.label92.Text = "Term";
            // 
            // comboBox12
            // 
            this.comboBox12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(384, 927);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(137, 25);
            this.comboBox12.TabIndex = 80;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(380, 905);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(114, 19);
            this.label93.TabIndex = 79;
            this.label93.Text = "Year Level / Grade *:";
            // 
            // comboBox13
            // 
            this.comboBox13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Location = new System.Drawing.Point(232, 927);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(137, 25);
            this.comboBox13.TabIndex = 78;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(228, 905);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(78, 19);
            this.label94.TabIndex = 77;
            this.label94.Text = "School Year *";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.CalendarFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker3.Location = new System.Drawing.Point(14, 932);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(202, 20);
            this.dateTimePicker3.TabIndex = 76;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(10, 905);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(111, 19);
            this.label95.TabIndex = 75;
            this.label95.Text = "Date of Graduation:";
            // 
            // comboBox14
            // 
            this.comboBox14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Location = new System.Drawing.Point(14, 858);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(137, 25);
            this.comboBox14.TabIndex = 74;
            // 
            // textBox66
            // 
            this.textBox66.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox66.Location = new System.Drawing.Point(507, 877);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(173, 25);
            this.textBox66.TabIndex = 73;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(503, 836);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(146, 38);
            this.label96.TabIndex = 72;
            this.label96.Text = "Program / Track & Strand / \r\nSpecialization";
            // 
            // textBox67
            // 
            this.textBox67.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox67.Location = new System.Drawing.Point(168, 858);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(323, 25);
            this.textBox67.TabIndex = 71;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(164, 836);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(98, 19);
            this.label97.TabIndex = 70;
            this.label97.Text = "Name of School:*";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(10, 836);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(81, 19);
            this.label98.TabIndex = 68;
            this.label98.Text = "School Type: *";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Gainsboro;
            this.panel8.Controls.Add(this.label99);
            this.panel8.Location = new System.Drawing.Point(3, 795);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(700, 38);
            this.panel8.TabIndex = 67;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(7, 9);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(178, 19);
            this.label99.TabIndex = 11;
            this.label99.Text = "Current or Last School Attended";
            // 
            // textBox68
            // 
            this.textBox68.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox68.Location = new System.Drawing.Point(384, 758);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(296, 25);
            this.textBox68.TabIndex = 66;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(380, 736);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(94, 19);
            this.label100.TabIndex = 65;
            this.label100.Text = "Email Address: *";
            // 
            // textBox69
            // 
            this.textBox69.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox69.Location = new System.Drawing.Point(202, 758);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(144, 25);
            this.textBox69.TabIndex = 64;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label101.Location = new System.Drawing.Point(198, 736);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(72, 19);
            this.label101.TabIndex = 63;
            this.label101.Text = "Mobile No.: *";
            // 
            // textBox70
            // 
            this.textBox70.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox70.Location = new System.Drawing.Point(14, 758);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(155, 25);
            this.textBox70.TabIndex = 62;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(10, 736);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(84, 19);
            this.label102.TabIndex = 61;
            this.label102.Text = "Telephone No.:";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Gainsboro;
            this.panel9.Controls.Add(this.label103);
            this.panel9.Location = new System.Drawing.Point(3, 695);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(700, 38);
            this.panel9.TabIndex = 60;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(7, 9);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(90, 19);
            this.label103.TabIndex = 11;
            this.label103.Text = "Contact Details";
            // 
            // textBox71
            // 
            this.textBox71.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox71.Location = new System.Drawing.Point(578, 654);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(102, 25);
            this.textBox71.TabIndex = 59;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(574, 632);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(55, 19);
            this.label104.TabIndex = 58;
            this.label104.Text = "Zip Code:";
            // 
            // textBox72
            // 
            this.textBox72.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox72.Location = new System.Drawing.Point(332, 654);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(223, 25);
            this.textBox72.TabIndex = 57;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(328, 632);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(58, 19);
            this.label105.TabIndex = 56;
            this.label105.Text = "Province:";
            // 
            // textBox73
            // 
            this.textBox73.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox73.Location = new System.Drawing.Point(370, 596);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(143, 25);
            this.textBox73.TabIndex = 48;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(366, 555);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(125, 38);
            this.label106.TabIndex = 47;
            this.label106.Text = "Subdivision / Village / \r\nBldg.:";
            // 
            // textBox74
            // 
            this.textBox74.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox74.Location = new System.Drawing.Point(537, 577);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(143, 25);
            this.textBox74.TabIndex = 46;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(533, 555);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(63, 19);
            this.label107.TabIndex = 45;
            this.label107.Text = "Barangay:";
            // 
            // textBox75
            // 
            this.textBox75.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox75.Location = new System.Drawing.Point(14, 654);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(293, 25);
            this.textBox75.TabIndex = 43;
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(10, 632);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(113, 19);
            this.label108.TabIndex = 42;
            this.label108.Text = "City / Municipality: *";
            // 
            // textBox76
            // 
            this.textBox76.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox76.Location = new System.Drawing.Point(202, 577);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(144, 25);
            this.textBox76.TabIndex = 41;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.Location = new System.Drawing.Point(198, 555);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(51, 19);
            this.label109.TabIndex = 40;
            this.label109.Text = "Street: *";
            // 
            // textBox77
            // 
            this.textBox77.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox77.Location = new System.Drawing.Point(14, 577);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(167, 25);
            this.textBox77.TabIndex = 39;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.Location = new System.Drawing.Point(10, 555);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(102, 19);
            this.label110.TabIndex = 38;
            this.label110.Text = "Street # / Unit #: *";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Gainsboro;
            this.panel10.Controls.Add(this.label111);
            this.panel10.Location = new System.Drawing.Point(3, 511);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(700, 38);
            this.panel10.TabIndex = 37;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.Location = new System.Drawing.Point(7, 9);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(163, 19);
            this.label111.TabIndex = 11;
            this.label111.Text = "Current / Permanent Address";
            // 
            // textBox78
            // 
            this.textBox78.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox78.Location = new System.Drawing.Point(457, 469);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(223, 25);
            this.textBox78.TabIndex = 36;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.Location = new System.Drawing.Point(453, 447);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(61, 19);
            this.label112.TabIndex = 35;
            this.label112.Text = "Religion: *";
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.CalendarFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker4.Location = new System.Drawing.Point(478, 417);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(202, 20);
            this.dateTimePicker4.TabIndex = 34;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.Location = new System.Drawing.Point(474, 390);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(85, 19);
            this.label113.TabIndex = 33;
            this.label113.Text = "Date of Birth: *";
            // 
            // textBox79
            // 
            this.textBox79.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox79.Location = new System.Drawing.Point(332, 412);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(125, 25);
            this.textBox79.TabIndex = 32;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.Location = new System.Drawing.Point(328, 390);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(77, 19);
            this.label114.TabIndex = 31;
            this.label114.Text = "Citizenship: *";
            // 
            // comboBox15
            // 
            this.comboBox15.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Location = new System.Drawing.Point(165, 412);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(142, 25);
            this.comboBox15.TabIndex = 30;
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label115.Location = new System.Drawing.Point(166, 390);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(54, 19);
            this.label115.TabIndex = 29;
            this.label115.Text = "Status: *";
            // 
            // comboBox16
            // 
            this.comboBox16.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Location = new System.Drawing.Point(9, 412);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(142, 25);
            this.comboBox16.TabIndex = 28;
            // 
            // textBox80
            // 
            this.textBox80.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox80.Location = new System.Drawing.Point(370, 357);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(143, 25);
            this.textBox80.TabIndex = 27;
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label116.Location = new System.Drawing.Point(366, 335);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(75, 19);
            this.label116.TabIndex = 26;
            this.label116.Text = "Last Name: *";
            // 
            // textBox81
            // 
            this.textBox81.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox81.Location = new System.Drawing.Point(537, 357);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(143, 25);
            this.textBox81.TabIndex = 25;
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label117.Location = new System.Drawing.Point(533, 335);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(76, 19);
            this.label117.TabIndex = 24;
            this.label117.Text = "Suffix Name:";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label118.Location = new System.Drawing.Point(10, 390);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(55, 19);
            this.label118.TabIndex = 22;
            this.label118.Text = "Gender: *";
            // 
            // textBox82
            // 
            this.textBox82.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox82.Location = new System.Drawing.Point(14, 469);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(427, 25);
            this.textBox82.TabIndex = 21;
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label119.Location = new System.Drawing.Point(10, 447);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(74, 19);
            this.label119.TabIndex = 20;
            this.label119.Text = "Birthplace: *";
            // 
            // textBox83
            // 
            this.textBox83.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox83.Location = new System.Drawing.Point(202, 357);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(144, 25);
            this.textBox83.TabIndex = 19;
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label120.Location = new System.Drawing.Point(198, 335);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(79, 19);
            this.label120.TabIndex = 18;
            this.label120.Text = "Middle Name:";
            // 
            // textBox84
            // 
            this.textBox84.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox84.Location = new System.Drawing.Point(14, 357);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(167, 25);
            this.textBox84.TabIndex = 17;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Gainsboro;
            this.panel11.Controls.Add(this.label121);
            this.panel11.Location = new System.Drawing.Point(3, 294);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(700, 38);
            this.panel11.TabIndex = 16;
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label121.Location = new System.Drawing.Point(7, 9);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(123, 19);
            this.label121.TabIndex = 11;
            this.label121.Text = "Student\'s Information";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label122.Location = new System.Drawing.Point(53, 149);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(45, 19);
            this.label122.TabIndex = 15;
            this.label122.Text = "Term: *";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.Location = new System.Drawing.Point(53, 180);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(50, 19);
            this.label123.TabIndex = 14;
            this.label123.Text = "Grade: *";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.Location = new System.Drawing.Point(53, 211);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(128, 19);
            this.label124.TabIndex = 13;
            this.label124.Text = "Senior High Program: *";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label125.Location = new System.Drawing.Point(53, 242);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(116, 38);
            this.label125.TabIndex = 12;
            this.label125.Text = "Learners Reference \r\n                     Number:";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label126.Location = new System.Drawing.Point(10, 335);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(76, 19);
            this.label126.TabIndex = 10;
            this.label126.Text = "First Name: *";
            // 
            // textBox85
            // 
            this.textBox85.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox85.Location = new System.Drawing.Point(207, 242);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(432, 25);
            this.textBox85.TabIndex = 9;
            // 
            // comboBox17
            // 
            this.comboBox17.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.Location = new System.Drawing.Point(207, 149);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(432, 25);
            this.comboBox17.TabIndex = 8;
            // 
            // comboBox18
            // 
            this.comboBox18.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.Location = new System.Drawing.Point(207, 180);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(432, 25);
            this.comboBox18.TabIndex = 7;
            // 
            // comboBox19
            // 
            this.comboBox19.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox19.FormattingEnabled = true;
            this.comboBox19.Location = new System.Drawing.Point(207, 211);
            this.comboBox19.Name = "comboBox19";
            this.comboBox19.Size = new System.Drawing.Size(432, 25);
            this.comboBox19.TabIndex = 6;
            // 
            // comboBox20
            // 
            this.comboBox20.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox20.FormattingEnabled = true;
            this.comboBox20.Location = new System.Drawing.Point(207, 118);
            this.comboBox20.Name = "comboBox20";
            this.comboBox20.Size = new System.Drawing.Size(432, 25);
            this.comboBox20.TabIndex = 5;
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label127.Location = new System.Drawing.Point(53, 118);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(80, 19);
            this.label127.TabIndex = 4;
            this.label127.Text = "School Year: *";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label128.Location = new System.Drawing.Point(53, 87);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(75, 19);
            this.label128.TabIndex = 3;
            this.label128.Text = "Admit Type: *";
            // 
            // textBox86
            // 
            this.textBox86.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox86.Location = new System.Drawing.Point(207, 87);
            this.textBox86.Name = "textBox86";
            this.textBox86.ReadOnly = true;
            this.textBox86.Size = new System.Drawing.Size(432, 25);
            this.textBox86.TabIndex = 2;
            this.textBox86.Text = "Old Student";
            // 
            // btnoldstu
            // 
            this.btnoldstu.AutoSize = true;
            this.btnoldstu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnoldstu.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnoldstu.IconChar = FontAwesome.Sharp.IconChar.File;
            this.btnoldstu.IconColor = System.Drawing.Color.Black;
            this.btnoldstu.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnoldstu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnoldstu.Location = new System.Drawing.Point(0, 0);
            this.btnoldstu.Name = "btnoldstu";
            this.btnoldstu.Size = new System.Drawing.Size(706, 77);
            this.btnoldstu.TabIndex = 0;
            this.btnoldstu.Text = "Old Student";
            this.btnoldstu.UseVisualStyleBackColor = true;
            this.btnoldstu.Click += new System.EventHandler(this.btnoldstu_Click);
            // 
            // AddStudData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.paneloldstud);
            this.Controls.Add(this.panelnewstud);
            this.Name = "AddStudData";
            this.Size = new System.Drawing.Size(736, 263);
            this.panelnewstud.ResumeLayout(false);
            this.panelnewstud.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.paneloldstud.ResumeLayout(false);
            this.paneloldstud.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private FontAwesome.Sharp.IconButton btnnewstud;
        private System.Windows.Forms.Panel panelnewstud;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Panel paneloldstud;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.ComboBox comboBox19;
        private System.Windows.Forms.ComboBox comboBox20;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.TextBox textBox86;
        private FontAwesome.Sharp.IconButton btnoldstu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}
